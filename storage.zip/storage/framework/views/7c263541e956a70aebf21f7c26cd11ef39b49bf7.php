<div class="activity">
    <div class="activity-icon bg-<?php echo e($status); ?> text-white shadow-<?php echo e($status); ?>">
        <i class="<?php echo e($icon); ?>"></i>
    </div>
    <div class="activity-detail" style="width:100%!important; overflow: auto">
        <input type="hidden" id="id_<?php echo e($no); ?>" name="id_<?php echo e($no); ?>" value="<?php echo e($data->id); ?>">
        <input type="hidden" id="mode_<?php echo e($no); ?>" name="mode_<?php echo e($no); ?>" value="ubah">
        <div class="row">
            <div class="col-sm-4">
                <div class="form-group">
                    <label>Tanggal Diterima</label>
                    <?php if($input_tgl!=null): ?>
                        <input class="datetimepickerindo form-control"
                               name="tgl_diterima_<?php echo e($no); ?>"
                               id="tgl_diterima_<?php echo e($no); ?>" required
                               type="text"
                               value="<?php echo e($input_tgl); ?>"/>
                    <?php else: ?>
                        <input class="datetimepickerindokosong form-control"
                               name="tgl_diterima_<?php echo e($no); ?>"
                               id="tgl_diterima_<?php echo e($no); ?>"
                               <?php echo e($data->status=='diteruskan' ? 'required' : ''); ?>

                               type="text"
                               value="<?php echo e($input_tgl); ?>" autocomplete="off"/>
                        <button onclick="set_tanggal(<?php echo e($loop->iteration); ?>)"
                                class="btn btn-sm btn-outline-primary mt-2"
                                type="button">
                            Set
                            Tgl
                            dan
                            Waktu
                        </button>

                        <button onclick="reset_tanggal(<?php echo e($loop->iteration); ?>)"
                                class="btn btn-sm btn-outline-danger mt-2"
                                type="button">
                            Reset
                            Tanggal
                        </button>
                    <?php endif; ?>
                    <div class="invalid-feedback"
                         id="error_tgl_diterima">
                    </div>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="form-group">
                    <label>Diterima oleh</label>
                    <input type="hidden" id="penerima_<?php echo e($no); ?>"
                           name="penerima_<?php echo e($no); ?>" class="form-control"
                           readonly value="<?php echo e($data->penerima); ?>">
                    <input type="text" id="opd_penerima_<?php echo e($no); ?>"
                           name="opd_penerima_<?php echo e($no); ?>"
                           class="form-control"
                           readonly value="<?php echo e(cek_opd($data->penerima)->nama_opd); ?>">

                </div>
            </div>
            <div class="col-sm-4">
                <div class="form-group">
                    <label>Nama Penerima</label>
                    <input class="form-control"
                           name="nama_penerima_<?php echo e($no); ?>"
                           id="nama_penerima_<?php echo e($no); ?>"
                           value="<?php echo e($data->nama_penerima ? $data->nama_penerima : Auth::user()->name); ?>"
                           required
                           placeholder="Nama Penerima">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-4">
                <div class="form-group">
                    <label>Status</label>
                    <select id="status_<?php echo e($no); ?>"
                            name="status_<?php echo e($no); ?>"
                            onchange="check_status(<?php echo e($loop->iteration); ?>)"
                            class="form-control" disabled>
                        <?php if(cekJenisOPD($data->penerima)!='opd'): ?>
                            <option
                                value="diteruskan" <?php echo e($data->status=='diteruskan' ? 'selected' : ''); ?>>
                                DITERUSKAN
                            </option>
                        <?php endif; ?>
                        <option
                            value="diolah" <?php echo e($data->status=='diolah' ? 'selected' : ''); ?>>
                            DIOLAH
                        </option>
                    </select>
                </div>
            </div>
            <div class="col-sm-4" id="div_kepada_<?php echo e($no); ?>"   <?php if($data->status=='diolah'): ?> style="display: none" <?php endif; ?>>
                <div class="form-group">
                    <label>Kepada</label>

                    <select id="kepada_<?php echo e($no); ?>"
                            name="kepada_<?php echo e($no); ?>[]"
                            class="form-control select_cari"
                            multiple <?php echo e($data->status=='diteruskan' ? 'required' : ''); ?> disabled>
                        <?php $__currentLoopData = $listPerangkat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nama => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option
                                value="<?php echo e($value); ?>" <?php echo e(array_search($value, explode (",", $data->kepada)) !== false ? 'selected' : ''); ?>><?php echo e($nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="col-sm-4" id="div_melalui_<?php echo e($no); ?>" <?php if($data->status=='diolah'): ?> style="display: none" <?php endif; ?>>
                <div class="form-group">
                    <label>Melalui/Langsung</label>
                    <select id="melalui_id_opd_<?php echo e($no); ?>"
                            name="melalui_id_opd_<?php echo e($no); ?>"
                            class="form-control select_cari" disabled
                            <?php if($data->status=='diteruskan'): ?> required <?php endif; ?>>

                        <?php $__currentLoopData = $listTu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nama => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option
                                value="<?php echo e($value); ?>" <?php echo e($value==$data->melalui_id_opd ? 'selected' : ''); ?>><?php echo e($nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <option
                            value="" <?php echo e($data->melalui_id_opd==null ? 'selected' : ''); ?>>
                            Langsung Tanpa Perantara
                        </option>
                    </select>
                </div>
            </div>
        </div>
        <div class="row" id="div_catatan_<?php echo e($no); ?>" <?php if($data->status=='diolah'): ?> style="display: none" <?php endif; ?>>
            <div class="col-sm-12">
                <div class="form-group">
                    <label>Catatan</label>
                    <textarea class="form-control"
                              style="min-height: 100px;"
                              rows="4"
                              placeholder="Ketik Catatan Disposisi..."
                              name="catatan_disposisi_<?php echo e($no); ?>"
                              id="catatan_disposisi_<?php echo e($no); ?>"><?php echo e($data->catatan_disposisi); ?></textarea>

                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\e-dokumen\resources\views/dashboard_page/suratmasuk/pengisianedit.blade.php ENDPATH**/ ?>