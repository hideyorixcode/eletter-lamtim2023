<div class="card author-box card-primary">
    <div class="card-body">
        <div class="author-box-left">
            <img alt="image" src="<?php echo e(getAvatar(Auth::user()->avatar)); ?>" class="rounded-circle author-box-picture">
            <div class="clearfix"></div>
            <a href="#" class="btn btn-primary mt-3 follow-btn"><?php echo e(Auth::user()->level); ?> <?php echo e(Auth::user()->level=='sespri' ? cek_opd(Auth::user()->id_opd_fk)->nama_opd : ''); ?> </a>
        </div>
        <div class="author-box-details">
            <div class="author-box-name">
                <a href="#"><?php echo e(Auth::user()->name); ?></a>
            </div>
            <div class="author-box-job"><?php echo e(Auth::user()->username); ?></div>
            <div class="author-box-description">
                <div class="form-group row my-2">
                    <label class="col-4 col-form-label">Email:</label>
                    <div class="col-8"><span
                            class="form-control-plaintext font-weight-bolder"><?php echo e(Auth::user()->email); ?></span>
                    </div>
                </div>
                <div class="form-group row my-2">
                    <label class="col-4 col-form-label">Status:</label>
                    <div class="col-8"><span
                            class="form-control-plaintext font-weight-bolder"><div class="<?php echo e(getActive(Auth::user()->active)); ?> text-small font-600-bold"><i class="fas fa-circle"></i> <?php echo e(getActiveTeks(Auth::user()->active)); ?></div></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card-footer">
        <ul class="nav nav-pills flex-column">
            <li class="nav-item"><a href="<?php echo e(route('profil')); ?>"
                                    class="nav-link <?php echo e($segment=='dashboard/profil' ? 'active' : ''); ?>">Profil</a>
            </li>
            <li class="nav-item"><a href="<?php echo e(route('ubah-password')); ?>"
                                    class="nav-link <?php echo e($segment=='dashboard/ubah-password' ? 'active' : ''); ?>">Ubah
                    Password</a></li>
            <li class="nav-item"><a href="<?php echo e(route('my-logs')); ?>"
                                    class="nav-link <?php echo e($segment=='dashboard/my-logs' ? 'active' : ''); ?>">Log
                    Saya</a>
            </li>
        </ul>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\e-dokumen\resources\views/dashboard_page/pengguna/side.blade.php ENDPATH**/ ?>