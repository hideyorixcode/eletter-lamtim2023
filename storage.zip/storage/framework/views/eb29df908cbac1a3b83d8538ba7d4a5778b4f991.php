<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0,user-scalable=0,minimal-ui">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="description" content="<?php echo e(getSetting('deskripsi')); ?>">
    <meta name="keywords" content="<?php echo e(getSetting('keyword')); ?>">
    <meta name="author" content="<?php echo e(getSetting('author')); ?>">
    <title><?php echo e(getSetting('nama_app')); ?> - <?php echo $__env->yieldContent('title'); ?></title>
    <!--favicon-->
    <link rel="icon" type="image/x-icon" href="<?php echo e(url('uploads/'.getSetting('favicon'))); ?>">
    <!--plugins-->
    <link rel="stylesheet" href="<?php echo e(assetku('assets/modules/bootstrap/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(assetku('assets/modules/fontawesome/css/all.min.css')); ?>">
    <?php echo $__env->yieldPushContent('vendor-css'); ?>
    <link rel="stylesheet" href="<?php echo e(assetku('assets/modules/izitoast/css/iziToast.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(assetku('assets/modules/sweetalert/sweetalert2.min.css')); ?>">
    <link href="https://fonts.googleapis.com/css2?family=Ubuntu:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500;1,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(assetku('assets/css/styledokumen.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(assetku('assets/css/components.css')); ?>">
    <?php echo $__env->yieldPushContent('library-css'); ?>
</head>

<body class="layout-3">
<div id="app">
    <div class="main-wrapper container">
        <div class="navbar-bg bg-warning"></div>
        <nav class="navbar navbar-expand-lg main-navbar">
            <a href="javascript:void(0)" class="navbar-brand sidebar-gone-hide" style="font-family: 'Ubuntu', sans-serif;!important;"><?php echo e(getSetting('nama_app')); ?>

            </a>
            <a href="#" class="nav-link sidebar-gone-show" data-toggle="sidebar"><i class="fas fa-bars"></i></a>
        </nav>
        <nav class="navbar navbar-secondary navbar-expand-lg">
            <div class="container">
                <ul class="navbar-nav">
                    <li class="nav-item active">
                        <a href="#" class="nav-link"><i class="fa fa-check-square"></i><span> <?php echo $__env->yieldContent('title'); ?> </span></a>
                    </li>
                </ul>
            </div>
        </nav>

        <!-- Main Content -->
        <div class="main-content">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        <footer class="main-footer">
            <div class="footer-left">
                Copyright &copy; <?php echo e(date('Y')); ?>

                <div class="bullet"></div>
                <?php echo e(getSetting('judul')); ?> By <a href="#"><?php echo e(getSetting('author')); ?></a>
            </div>
            <div class="footer-right">
                1.0
            </div>
        </footer>
    </div>
</div>

<!-- General JS Scripts -->
<script src="<?php echo e(assetku('assets/modules/jquery.min.js')); ?>"></script>
<script src="<?php echo e(assetku('assets/modules/popper.js')); ?>"></script>
<script src="<?php echo e(assetku('assets/modules/tooltip.js')); ?>"></script>
<script src="<?php echo e(assetku('assets/modules/bootstrap/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(assetku('assets/modules/nicescroll/jquery.nicescroll.min.js')); ?>"></script>
<script src="<?php echo e(assetku('assets/modules/moment.min.js')); ?>"></script>
<script src="<?php echo e(assetku('assets/js/stisla.js')); ?>"></script>
<script src="<?php echo e(assetku('assets/modules/izitoast/js/iziToast.min.js')); ?>"></script>
<script src="<?php echo e(assetku('assets/modules/sweetalert/sweetalert2.min.js')); ?>"></script>
<!-- JS Libraies -->

<!-- Template JS File -->
<script src="<?php echo e(assetku('assets/js/scripts.js')); ?>"></script>
<script src="<?php echo e(assetku('assets/js/custom.js')); ?>"></script>

<!-- Page Specific JS File -->
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH D:\laragon\www\e-dokumen\resources\views/mylayouts/front.blade.php ENDPATH**/ ?>