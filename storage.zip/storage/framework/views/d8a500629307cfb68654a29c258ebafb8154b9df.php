<?php $__env->startSection('title', 'Data PTHL No Urut '.$dataPthl->pthl_urut); ?>
<?php $__env->startPush('vendor-css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-body">
            <div class="row">
                <?php if($kondisi == 'salah'): ?>
                    <div class="col-md-12 mt-2">
                        <div class="card">
                            <div class="card-body">
                                <div class="alert alert-<?php echo e($status); ?> mb-2" role="alert"> <?php echo e($pesan); ?> </div>
                                <form method="get" action="<?php echo e(url('sk-pthl/'.$dataPthl->pthl_urut)); ?>">
                                    <div class="form-group">
                                        <div class="input-group mb-3">
                                            <div class="input-group-prepend">
                                            <span class="input-group-text" id="basic-addon1"><i
                                                    class="fas fa-search"></i></span>
                                            </div>

                                            <input type="number" class="form-control" name="nik"
                                                   placeholder="Input NIK dan Tekan Enter"
                                                   aria-label="Username" aria-describedby="basic-addon1">

                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                <div class="col-md-8 mt-2">
                    <div class="card">
                        <div class="card-header">
                            <h4>Data PTHL </h4>
                        </div>

                        <div class="card-body">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">No Urut</label>

                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php echo e($dataPthl->pthl_urut); ?>

                                    </label>
                                </div>
                            </div>
                            <hr class="mb-2">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">Nama</label>

                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php echo e($dataPthl->pthl_nama); ?>

                                    </label>
                                </div>
                            </div>

                            <hr class="mb-2">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">NIK</label>

                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php
                                        $getNik = substr($dataPthl->pthl_nik, 0, -7) . str_repeat('*', 5);
                                        //$getNik = substr($dataPthl->pthl_nik, -7)
                                        ?>
                                        <?php echo e($getNik); ?>

                                    </label>
                                </div>
                            </div>


                            <hr class="mb-2">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">Tempat Lahir</label>

                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php echo e($dataPthl->pthl_tempat_lahir); ?>

                                    </label>
                                </div>
                            </div>


                            <hr class="mb-2">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">Tanggal Lahir</label>

                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php
                                        $getTanggal = substr(TanggalIndo2($dataPthl->pthl_tgl_lahir), 0, -4) . str_repeat('*', 4);
                                        //$getNik = substr($dataPthl->pthl_nik, -7)
                                        ?>
                                        <?php echo e($getTanggal); ?>

                                    </label>
                                </div>
                            </div>

                            <hr class="mb-2">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">Pendidikan</label>

                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php echo e($dataPthl->pthl_pendidikan); ?>

                                    </label>
                                </div>
                            </div>

                            <hr class="mb-2">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">Tugas</label>

                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php echo e($dataPthl->pthl_tugas); ?>

                                    </label>
                                </div>
                            </div>

                            <hr class="mb-2">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">Instansi</label>

                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php echo e($dataPthl->pthl_opd); ?>

                                    </label>
                                </div>
                            </div>

                        </div>

                    </div>

                </div>
                <div class="col-md-4 mt-2">
                    <div class="card">
                        <div class="card-body">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">No SK</label>

                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php echo e($dataMaster->dokumen_nomor); ?>

                                    </label>
                                </div>
                            </div>
                            <hr class="mb-2">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">Tentang</label>

                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php echo e($dataMaster->dokumen_hal); ?>

                                    </label>
                                </div>
                            </div>

                            <hr class="mb-2">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">dto</label>

                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php echo e($ttd); ?>

                                    </label>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>

    <!--end::Page Vendors-->
    <!--begin::Page Scripts(used by this page)-->
    <script src="<?php echo e(assetku('assets/jshideyorix/general.js')); ?>"></script>
    <script>
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('mylayouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\e-dokumen\resources\views/dashboard_page/pthl/detailverifikasi.blade.php ENDPATH**/ ?>