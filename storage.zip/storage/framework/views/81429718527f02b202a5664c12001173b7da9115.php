<?php $__env->startSection('title', 'Detail Pimpinan / Perangkat Daerah'); ?>
<?php $__env->startPush('library-css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h1>Detail Pimpinan / Perangkat Daerah</h1>
            <div class="section-header-breadcrumb">
                <div class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></div>
                <div class="breadcrumb-item"><a href="<?php echo e(route('perangkat-daerah')); ?>">Daftar PD</a></div>
                <div class="breadcrumb-item active">Detail PD</div>
            </div>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-sm-8 order-sm-0 order-lg-1 order-xl-1">
                    <div class="card">
                        <div class="card-body">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">1. Nama Perangkat
                                        Daerah</label>
                                    <label class="col-sm-1 col-lg-1 col-form-label">:</label>
                                    <label class="col-sm-6 col-lg-6 col-form-label font-weight-bolder">
                                        <?php echo e($nama_opd); ?>

                                    </label>
                                </div>
                            </div>
                            <hr class="mb-2">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">2. Alias Perangkat
                                        Daerah</label>
                                    <label class="col-sm-1 col-lg-1 col-form-label">:</label>
                                    <label class="col-sm-6 col-lg-6 col-form-label font-weight-bolder">
                                        <?php echo e($alias_opd); ?>

                                    </label>
                                </div>
                            </div>
                            <hr class="mb-2">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">3. Alamat</label>
                                    <label class="col-sm-1 col-lg-1 col-form-label">:</label>
                                    <label class="col-sm-6 col-lg-6 col-form-label font-weight-bolder">
                                        <?php echo e($alamat_opd); ?>

                                    </label>
                                </div>
                            </div>
                            <hr class="mb-2">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">4. Email</label>
                                    <label class="col-sm-1 col-lg-1 col-form-label">:</label>
                                    <label class="col-sm-6 col-lg-6 col-form-label font-weight-bolder">
                                        <?php echo e($email_opd); ?>

                                    </label>
                                </div>
                            </div>
                            <hr class="mb-2">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">5. No Telepon</label>
                                    <label class="col-sm-1 col-lg-1 col-form-label">:</label>
                                    <label class="col-sm-6 col-lg-6 col-form-label font-weight-bolder">
                                        <?php echo e($notelepon_opd); ?>

                                    </label>
                                </div>
                            </div>
                            <hr class="mb-2">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">6. Status</label>
                                    <label class="col-sm-1 col-lg-1 col-form-label">:</label>
                                    <label class="col-sm-6 col-lg-6 col-form-label font-weight-bolder">
                                        <div class="<?php echo e(getActive($active)); ?> text-small font-600-bold"><i
                                                class="fas fa-circle"></i> <?php echo e(getActiveTeks($active)); ?></div>
                                    </label>
                                </div>
                            </div>
                            <hr class="mb-2">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">7. Jenis</label>
                                    <label class="col-sm-1 col-lg-1 col-form-label">:</label>
                                    <label class="col-sm-6 col-lg-6 col-form-label font-weight-bolder">
                                        <?php if($jenis == 'opd'): ?>
                                            <div class="badge badge-warning">OPD</div>
                                        <?php elseif($jenis == 'pimpinan daerah'): ?>
                                            <div class="badge badge-primary">PIMPINAN DAERAH</div>
                                        <?php elseif($jenis == 'sekretariat daerah'): ?>
                                            <div class="badge badge-success">SEKRETARIAT DAERAH</div>
                                        <?php elseif($jenis == 'tu'): ?>
                                            <div class="badge badge-dark">TU</div>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer text-right bg-whitesmoke">

                            <a href="<?php echo e(route('perangkat-daerah')); ?>" class="btn btn-secondary mr-2">Kembali</a>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 order-sm-0 order-lg-0 order-xl-0">
                    <div class="card">
                        <div class="card-body">
                            <div class="empty-state">
                                <img class="img-fluid"
                                     src="<?php echo e(assetku('assets/img/drawkit/drawkit-full-stack-man-colour.svg')); ?>"
                                     alt="image">
                                <h2 class="mt-0 mb-2">Data Pimpinan / Perangkat Daerah</h2>
                                <?php if(count($errors) > 0): ?>
                                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                        <div class="alert-body">
                                            <ul>
                                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><?php echo e($error); ?></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">×</span>
                                        </button>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(assetku('assets/jshideyorix/general.js')); ?>"></script>
    <!--begin::Page Scripts(used by this page)-->
    <script type="text/javascript">
        <?php if(session('pesan_status')): ?>
        tampilPesan('<?php echo e(session('pesan_status.tipe')); ?>', '<?php echo e(session('pesan_status.desc')); ?>', '<?php echo e(session('pesan_status.judul')); ?>');
        <?php endif; ?>
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('mylayouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\e-dokumen\resources\views/dashboard_page/perangkat-daerah/show.blade.php ENDPATH**/ ?>