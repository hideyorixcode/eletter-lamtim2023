<?php $__env->startSection('title', 'Dokumen Khusus'); ?>
<?php $__env->startPush('vendor-css'); ?>
    <!--begin::Page Vendors Styles(used by this page)-->
    <link rel="stylesheet" href="<?php echo e(assetku('assets/modules/datatables/datatables.min.css')); ?>">
    <link rel="stylesheet"
          href="<?php echo e(assetku('assets/modules/datatables/DataTables-1.10.16/css/dataTables.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(assetku('assets/modules/datatables/Select-1.2.4/css/select.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(assetku('assets/modules/select2/dist/css/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(assetku('assets/modules/datatables/Buttons/css/buttons.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(assetku('assets//modules/bootstrap-daterangepicker/daterangepicker.css')); ?>">
    <!--end::Page Vendors Styles-->
<?php $__env->stopPush(); ?>
<?php $__env->startPush('library-css'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <!--begin::Card-->

    <section class="section">
        <div class="section-header">
            <h1>Dokumen Khusus</h1>
            <div class="section-header-button">
                <a href="javascript:add()"
                   class="btn btn-primary btn-sm"><i
                        class="fa fa-plus mr-50"></i>
                    Tambah
                </a>
            </div>
            <div class="section-header-breadcrumb">
                <div class="breadcrumb-item active"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></div>
                <div class="breadcrumb-item">Dokumen Khusus</div>
            </div>
        </div>

        <div class="section-body">


            <div class="card">
                <div class="card-body">
                    <table class="table table-striped table-bordered" id="hideyori_datatable">
                        <thead>
                        <tr>
                            <th><input type="checkbox" id="check-all"></th>
                            <th>No.</th>
                            <th>Nomor Dokumen</th>
                            <th>Tanggal Dokumen</th>
                            <th>Tentang</th>
                            <th>Jenis Penandatangan</th>
                            <th>Pimpinan/Perangkat Daerah</th>
                            <th>Jenis</th>
                            
                            <th>Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>

                <?php if(in_array(Auth::user()->level, ['admin', 'superadmin'])): ?>
                    <div class="card-footer">
                        <div class="row">
                            <div class="col-lg-6  col-xl-6 col-6 text-left" id="div_opsi"
                                 style="display: none">
                                <div class="dropdown d-inline">
                                    <button class="btn btn-dark dropdown-toggle" type="button"
                                            id="dropdownMenuButton2"
                                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        Pilih Opsi
                                    </button>
                                    <div class="dropdown-menu">
                                        <a class="dropdown-item has-icon" href="javascript:bulkDelete()"><i
                                                class="fa fa-trash text-danger"></i> Hapus</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6  col-xl-6 col-6 text-right" id="div_ekspor"
                                 style="display: none">
                            </div>
                        </div>
                    </div>
            <?php endif; ?>
            <!--begin::Dropdown-->

            </div>

        </div>
    </section>

    <!-- Modal -->
    <div
        class="modal fade"
        id="modal_form"
        
        role="dialog"
        aria-labelledby="exampleModalScrollableTitle"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <form class="form form-horizontal" id="form" name="form" method="post"
                      enctype="multipart/form-data" action="javascript:save();">
                    <div class="modal-header bg-dark text-white" style="padding-top: 10px; padding-bottom: 10px">
                        <h6 class="modal-title" id="judul">Modal title</h6>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>

                    <div class="modal-body" style="max-height: 400px;">

                        <div class="row">
                            <div class="col-12">
                                <div class="form-group row">
                                    <div class="col-sm-3 col-form-label">
                                        <label>Nomor Dokumen</label>
                                    </div>
                                    <div class="col-sm-9">
                                        <input type="hidden" id="dokumen_id" class="form-control"
                                               name="dokumen_id">
                                        <input type="text" id="dokumen_nomor" class="form-control"
                                               name="dokumen_nomor">
                                        <div class="invalid-feedback" id="error_dokumen_nomor">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-12">
                                <div class="form-group row">
                                    <div class="col-sm-3 col-form-label">
                                        <label>Tanggal Dokumen</label>
                                    </div>
                                    <div class="col-sm-9">
                                        <input type="text" id="dokumen_tanggal" class="form-control"
                                               name="dokumen_tanggal">
                                        <div class="invalid-feedback" id="error_dokumen_tanggal">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-12">
                                <div class="form-group row">
                                    <div class="col-sm-3 col-form-label">
                                        <label>Hal (Tentang)</label>
                                    </div>
                                    <div class="col-sm-9">
                                        <input type="text" id="dokumen_hal" class="form-control"
                                               name="dokumen_hal"
                                               placeholder="Bunyi Dokumen">
                                        <div class="invalid-feedback" id="error_dokumen_hal">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-12">
                                <div class="form-group row">
                                    <div class="col-sm-3 col-form-label">
                                        <label>Pimpinan / Perangkat Daerah</label>
                                    </div>
                                    <div class="col-sm-9">
                                        <select class="select_cari form-control" id="id_opd"
                                                name="id_opd">
                                            <?php $__currentLoopData = $listPerangkat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nama => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option
                                                    value=<?php echo e($value); ?>><?php echo e($nama); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <div class="invalid-feedback" id="error_id_opd">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-12">
                                <div class="form-group row">
                                    <div class="col-sm-3 col-form-label">
                                        <label>Penandatangan</label>
                                    </div>
                                    <div class="col-sm-9">
                                        <select class="select_cari form-control" id="dokumen_jenis_ttd"
                                                name="dokumen_jenis_ttd">
                                            <?php $__currentLoopData = $listJenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option
                                                    value=<?php echo e($jenis->id_jenis_ttd); ?>><?php echo e($jenis->jenis_ttd.' - '.$jenis->nama_opd); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <div class="invalid-feedback" id="error_dokumen_jenis_ttd">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-12">
                                <div class="form-group row">
                                    <div class="col-sm-3 col-form-label">
                                        <label>Jenis Dokumen</label>
                                    </div>
                                    <div class="col-sm-9">
                                        <select class="form-control" id="dokumen_jenis"
                                                name="dokumen_jenis">
                                            <option value="SK PNS JABATAN PELAKSANA">SK PNS JABATAN PELAKSANA</option>
                                            <option value="SK PTHL">SK PTHL</option>
                                            <option value="PERJANJIAN KERJA PPPK">PERJANJIAN KERJA PPPK</option>
                                            <option value="LAINNYA">LAINNYA</option>
                                        </select>
                                        <div class="invalid-feedback" id="error_dokumen_jenis">
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <div class="col-12">
                                <div class="form-group row">
                                    <div class="col-sm-3 col-form-label">
                                        <label>Upload Master File</label>
                                    </div>
                                    <div class="col-sm-9">
                                        <input type="file" id="dokumen_file" class="form-control"
                                               name="dokumen_file" accept="application/pdf">
                                        <p class="invalid-feedback" style="color: red" id="error_dokumen_file">
                                        </p>
                                        <p class="mt-2" id="dokumen_file_text"></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer bg-whitesmoke">
                        <button type="submit" id="btnsave"
                                class="btn btn-primary mr-1 waves-effect waves-float waves-light">
                            <i class="fa fa-save"></i> <span id="teksSimpan"> Submit</span>
                        </button>
                        <button type="button" id="btnbatal" onclick="add()"
                                class="btn btn-outline-secondary waves-effect"
                                style="display: none">
                            Batal
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(assetku('assets/modules/datatables/datatables.min.js')); ?>"></script>
    <script
        src="<?php echo e(assetku('assets/modules/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(assetku('assets/modules/datatables/Select-1.2.4/js/dataTables.select.min.js')); ?>"></script>
    <script src="<?php echo e(assetku('assets/modules/select2/dist/js/select2.full.min.js')); ?>"></script>
    <script src="<?php echo e(assetku('assets/modules/jquery-ui/jquery-ui.min.js')); ?>"></script>
    <script src="<?php echo e(assetku('assets/modules/bootstrap-daterangepicker/daterangepicker.js')); ?>"></script>
    <!--end::Page Vendors-->
    <!--begin::Page Scripts(used by this page)-->
    <script src="<?php echo e(assetku('assets/jshideyorix/general.js')); ?>"></script>
    <script src="<?php echo e(assetku('assets/jshideyorix/mydatatable.js')); ?>"></script>
    <script src="<?php echo e(assetku('assets/jshideyorix/deletertable.js')); ?>"></script>
    <?php echo $__env->make('components.buttonDatatables', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--end::Page Vendors-->
    <!--begin::Page Scripts(used by this page)-->
    <script type="text/javascript">

        <?php if(session('pesan_status')): ?>
        tampilPesan('<?php echo e(session('pesan_status.tipe')); ?>', '<?php echo e(session('pesan_status.desc')); ?>', '<?php echo e(session('pesan_status.judul')); ?>');
        <?php endif; ?>

        if (jQuery().daterangepicker) {
            if ($("#dokumen_tanggal").length) {
                $('#dokumen_tanggal').daterangepicker({
                    locale: {format: 'DD/MM/YYYY'},
                    singleDatePicker: true,
                });
            }
        }

        $(document).ready(function () {
            table = $('#hideyori_datatable').DataTable({
                aLengthMenu: [
                    [10, 50, 100, -1],
                    [10, 50, 100, "All"]
                ],
                paging: true,
                processing: true,
                serverSide: true,
                responsive: true,
                autoWidth: false,
                language: {
                    search: "_INPUT_",
                    searchPlaceholder: "Cari dan Tekan Enter..."
                },
                
                ajax: {
                    url: "<?php echo e(route('dokumen-khusus.data')); ?>",
                    type: "GET",
                },
                columns: [
                    {
                        data: 'checkbox',
                        name: 'checkbox',
                        orderable: false,
                        searchable: false,
                        className: 'text-center',
                        responsivePriority: -1
                    },
                    {
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false,
                        className: 'text-center'
                    },
                    {data: 'dokumen_nomor', name: 'dokumen_nomor', responsivePriority: -1},
                    {data: 'dokumen_tanggal', name: 'dokumen_tanggal'},
                    {data: 'dokumen_hal', name: 'dokumen_hal'},
                    {data: 'dokumen_jenis_ttd', name: 'dokumen_jenis_ttd'},
                    {data: 'id_opd', name: 'id_opd'},
                    {data: 'dokumen_jenis', name: 'dokumen_jenis'},
                    // {
                    //     data: 'dokumen_file',
                    //     name: 'dokumen_file',
                    //     orderable: false,
                    //     searchable: false,
                    //     className: 'text-center'
                    // },
                    {data: 'action', name: 'action', orderable: false, searchable: false, className: 'text-center'},
                ],

                rowCallback: function (row, data, index) {
                    cellValue = data['dokumen_id'];
                    // console.log(cellValue);
                    var html = $(row);
                    if (array_data.includes(cellValue, 0)) {
                        var input = html.find('input[type=checkbox]').prop('checked', 'checked')
                    }
                },
                drawCallback: function () {
                    $('.data-check').on('change', function () {
                        console.log($(this).val());
                        if ($(this).is(':checked')) {
                            array_data.push($(this).val())
                        } else {
                            var index = array_data.indexOf($(this).val());
                            if (index !== -1) {
                                array_data.splice(index, 1);
                            }
                        }
                    });
                    var totalData = table.page.info().recordsTotal;
                    if (totalData > 0) {
                        $('#div_opsi').show();
                        $('#div_ekspor').html('');
                        $('#div_ekspor').show();
                        $('#check-all').show();

                        exporni = '1,2,3,4,5,6,7';


                        var buttons_dom = new $.fn.dataTable.Buttons(table, {
                            buttons: [
                                {
                                    extend: 'print',
                                    text: 'Print',
                                    title: 'Dokumen Khusus',
                                    customize: function (win) {
                                        $(win.document.body).find('h1').css('text-align', 'center');
                                    },
                                    exportOptions: {
                                        columns: exporni
                                        //columns : '0,1,2,3,4,5,6,7,8'
                                    }
                                },
                                {
                                    extend: 'copyHtml5',
                                    text: 'Copy',
                                    title: 'Dokumen Khusus',
                                    exportOptions: {
                                        //columns: ':visible'
                                        columns: exporni
                                    }
                                },
                                {
                                    extend: 'excelHtml5',
                                    text: 'Excel',
                                    title: 'Dokumen Khusus',
                                    exportOptions: {
                                        //columns: ':visible'
                                        columns: exporni
                                    }
                                },

                            ]
                        }).container().appendTo($('#div_ekspor'));
                    } else {
                        $('#div_opsi').hide();
                        $('#div_ekspor').hide();
                        $('#check-all').hide();
                    }
                    initClick();
                },
                "error": function (xhr, error, thrown) {
                    console.log("Error occurred!");
                    console.log(xhr, error, thrown);
                }
            });

            $('#hideyori_datatable_filter input').unbind();
            $('#hideyori_datatable_filter input').bind('keyup', function (e) {
                if (e.keyCode == 13) {
                    table.search(this.value).draw();
                }
            });

            $('#hideyori_datatable').on('error.dt', function (e, settings, techNote, message) {
                console.log('An error has been reported by DataTables: ', message);
            }).DataTable();

            table.on('responsive-display', function (e, datatable, row, showHide, update) {
                initClick();
            });


        });

        function deleteData(paramId) {
            var url = '<?php echo e(url('dashboard/dokumen-khusus/delete/')); ?>';
            deleteDataTable(paramId, url);
        }


        function bulkDelete() {
            var url = '<?php echo e(url('dashboard/dokumen-khusus/bulkDelete/')); ?>';
            bulkDeleteTable(url)
        }

        $('#modal_form').on('shown.bs.modal', function () {
            $('#dokumen_nomor').focus()
        })

        function add() {
            $('#modal_form').modal();
            $('#modal_form').appendTo("body");
            $('#modal_form').modal('show'); // show bootstrap modal
            save_method = 'add';
            $('#form')[0].reset(); // reset form on modals
            $('.form-control').removeClass('is-invalid'); // clear error class
            $('.invalid-feedback').empty(); // clear error string
            $('#judul').text('FORM TAMBAH DOKUMEN KHUSUS'); // Set Title to Bootstrap modal title
            $('#teksSimpan').text('Tambah');
            $('#btnsave').show();
            $('#dokumen_file_text').text("");
            $('[name="dokumen_nomor"]').prop('disabled', false);
            $('[name="dokumen_tanggal"]').prop('disabled', false);
            $('[name="dokumen_hal"]').prop('disabled', false);
            $('[name="id_opd"]').prop('disabled', false);
            $('[name="dokumen_jenis_ttd"]').prop('disabled', false);
            $('[name="dokumen_file"]').prop('disabled', false);
            $('[name="id_opd"]').val(1).trigger('change');
            $('[name="dokumen_jenis_ttd"]').val(1).trigger('change');
            $('[name="dokumen_jenis"]').val(1).trigger('change');
            $('#btnbatal').hide();
        }

        function initClick() {
            $(".clickable-edit").click(function () {
                save_method = 'update';
                dokumen_id = $(this).attr('data-dokumen_id');
                dokumen_hal = $(this).attr('data-dokumen_hal');
                dokumen_seo = $(this).attr('data-dokumen_seo');
                dokumen_jenis_ttd = $(this).attr('data-dokumen_jenis_ttd');
                dokumen_nomor = $(this).attr('data-dokumen_nomor');
                dokumen_file = $(this).attr('data-dokumen_file');
                id_opd = $(this).attr('data-id_opd');
                dokumen_jenis = $(this).attr('data-dokumen_jenis');
                dokumen_tanggal = $(this).attr('data-dokumen_tanggal');
                $('#form')[0].reset(); // reset form on modals
                $('.form-control').removeClass('is-invalid'); // clear error class
                $('.invalid-feedback').empty(); // clear error string
                $('#modal_form').modal();
                $('#modal_form').appendTo("body");
                $('#modal_form').modal('show'); // sh
                $('[name="dokumen_id"]').val(dokumen_id);
                $('[name="dokumen_hal"]').val(dokumen_hal);
                $('[name="dokumen_tanggal"]').val(dokumen_tanggal);
                $('[name="dokumen_jenis"]').val(dokumen_jenis).trigger('change');
                $('[name="dokumen_jenis_ttd"]').val(dokumen_jenis_ttd).trigger('change');
                $('[name="dokumen_nomor"]').val(dokumen_nomor);
                $('[name="id_opd"]').val(id_opd).trigger('change');
                $('#judul').text('FORM UBAH DOKUMEN KHUSUS'); // Set Title to Bootstrap modal titlep modal title
                $('#teksSimpan').text('Simpan Perubahan');
                $('#dokumen_file_text').text(dokumen_file);
                $('#btnsave').show();
                $('[name="dokumen_nomor"]').prop('disabled', false);
                $('[name="dokumen_hal"]').prop('disabled', false);
                $('[name="dokumen_tanggal"]').prop('disabled', false);
                $('[name="id_opd"]').prop('disabled', false);
                $('[name="dokumen_jenis_ttd"]').prop('disabled', false);
                $('[name="dokumen_file"]').prop('disabled', false);
                $('[name="dokumen_jenis"]').prop('disabled', false);
                $('#btnbatal').show();
                $('#btnbatal').text('Batal Ubah');
            });
        }


        function save() {
            var url;
            var _method;
            var id;
            var formData = new FormData($('#form')[0]);
            if (save_method == 'add') {
                id = '';
                url = "<?php echo e(url('dashboard/dokumen-khusus/create/')); ?>";
                _method = "POST";
            } else {
                id = $('[name="dokumen_id"]').val();
                url = '<?php echo e(url('dashboard/dokumen-khusus/update/')); ?>' + '/' + id;
                _method = "PUT";
                formData.append('_method', 'PUT');
            }

            var token = $('meta[name="csrf-token"]').attr('content');
            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': token
                },
                url: url,
                type: 'POST',
                data: formData,
                dataType: "JSON",
                cache: false,
                contentType: false,
                processData: false,
                success: function (data) {
                    if (data.status) //if success close modal and reload ajax table
                    {
                        if (save_method == 'add') {
                            reloadTable();
                            iziToast.success({
                                title: 'Sukses',
                                message: 'Berhasil Input Data',
                                position: 'topRight'
                            });
                            $('#modal_form').modal('hide');
                        } else {
                            reloadTable();
                            iziToast.success({
                                title: 'Sukses',
                                message: 'Berhasil Ubah Data',
                                position: 'topRight'
                            });
                            $('#modal_form').modal('hide');
                        }
                    } else {
                        for (var i = 0; i < data.inputerror.length; i++) {
                            $('[name="' + data.inputerror[i] + '"]').addClass('is-invalid'); //select parent twice to
                            $('#error_' + data.inputerror[i] + '').text(data.error_string[i]);
                            $('[name="' + data.inputerror[i] + '"]').focus();
                        }
                    }
                },
                error: function (xhr) {
                    iziToast.error({
                        title: 'Error',
                        message: xhr.responseText,
                        position: 'topRight'
                    });
                }
            });
        }

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('mylayouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\e-dokumen\resources\views/dashboard_page/master-dokumen/index.blade.php ENDPATH**/ ?>