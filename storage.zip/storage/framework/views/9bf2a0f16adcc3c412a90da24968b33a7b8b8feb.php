<?php $__env->startSection('title', 'Form '.ucwords($mode).' Surat Keluar '); ?>
<?php $__env->startPush('vendor-css'); ?>
    <link rel="stylesheet" href="<?php echo e(assetku('magnific-popup/magnific-popup.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(assetku('assets/modules/datatables/Select-1.2.4/css/select.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(assetku('assets/modules/select2/dist/css/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(assetku('assets//modules/bootstrap-daterangepicker/daterangepicker.css')); ?>">

    <style>
        .select_sm {
            height: 33.22222px !important;
            padding-bottom: 2px !important;
            padding-top: 2px !important;
            padding-right: 2px !important;
            padding-left: 2px !important;
        }

        #the-canvas {
            border: 1px solid black;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h1><?php echo e('Form '.ucwords($mode).' Surat Keluar '); ?></h1>
            <div class="section-header-breadcrumb">
                <div class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></div>
                <div class="breadcrumb-item"><a href="<?php echo e(route('surat-keluar')); ?>">Daftar Surat Keluar </a></div>
                <div class="breadcrumb-item active"><?php echo e('Form '.ucwords($mode).' Surat Keluar '); ?></div>
            </div>
        </div>
        <div class="section-body">
            <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <div class="alert-body">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
            <?php endif; ?>
            <form id="form" name="form" role="form" action="<?php echo e($action); ?>"
                  enctype="multipart/form-data" method="post">
                <?php echo e(csrf_field()); ?>

                <?php if($mode=='ubah'): ?>
                    <?php echo e(method_field('PUT')); ?>

                <?php endif; ?>
                <input name="diisi_oleh" id="diisi_oleh" type="hidden" value="<?php echo e($diisi_oleh); ?>">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group" id="div_nosurat">
                                            <label>No Surat</label>
                                            <div class="input-group">
                                                     <span
                                                         class="input-group-prepend">
                                                     <label
                                                         class="input-group-text">
                                                     <i class="fa fa-list"></i></label>
                                                     </span>
                                                <input class="form-control <?php $__errorArgs = ['no_surat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                       name="no_surat" id="no_surat"
                                                       type="text" value="<?php echo e($no_surat); ?>">
                                            </div>
                                            <?php $__errorArgs = ['no_surat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="form-group">
                                            <label>Tgl Surat</label>

                                            <div class="input-group">
                                                        <span class="input-group-prepend">
                                                        <label class="input-group-text">
                                                        <i class="fa fa-calendar"></i></label>
                                                        </span>
                                                <input class="form-control <?php $__errorArgs = ['tgl_surat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                       name="tgl_surat" id="tgl_surat"
                                                       type="text" value="<?php echo e($tgl_surat); ?>">
                                            </div>
                                            <?php $__errorArgs = ['tgl_surat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        </div>
                                    </div>
                                    <div class="col-sm-2">
                                        <div class="form-group">
                                            <label>Lampiran</label>


                                            <input class="form-control <?php $__errorArgs = ['lampiran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                   name="lampiran" id="lampiran"
                                                   type="number" value="<?php echo e($lampiran); ?>">

                                            <?php $__errorArgs = ['lampiran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label>Dari</label>

                                    <select class="select_cari form-control" id="id_opd_fk"
                                            name="id_opd_fk">
                                        <?php $__currentLoopData = $listPerangkat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nama => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option
                                                value=<?php echo e($value); ?> <?php echo e($value==$id_opd_fk ? 'selected' : ''); ?>><?php echo e($nama); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['id_opd_fk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>
                                <div class="form-group">
                                    <label>Tujuan</label>
                                    <br/>
                                    <div class="form-check form-check-inline mb-3">
                                        <input class="form-check-input" type="radio" id="inlineradio1"
                                               name="tujuan" value="dalam"
                                               onchange="cektujuan()" <?php if($tujuan=='dalam'): ?> checked <?php endif; ?>>
                                        <label class="form-check-label" for="inlineradio1">Antar Instansi</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" id="inlineradio2"
                                               name="tujuan" value="luar"
                                               onchange="cektujuan()"
                                               <?php if($tujuan=='luar' || $tujuan==''): ?> checked <?php endif; ?>>
                                        <label class="form-check-label" for="inlineradio2">Lainnya</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" id="inlineradio3"
                                               name="tujuan" value="keduanya"
                                               onchange="cektujuan()" <?php if($tujuan=='keduanya'): ?> checked <?php endif; ?>>
                                        <label class="form-check-label" for="inlineradio3">Atur Keduanya</label>
                                    </div>
                                    <div id="divkepadaselect">
                                        <select class="select_cari_placeholder form-control" id="kepada_id_opd"
                                                name="kepada_id_opd[]" multiple>
                                            <?php $__currentLoopData = $listPerangkat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nama => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option
                                                    value="<?php echo e($value.';'.$nama); ?>" <?php echo e(array_search($value, explode (",", $kepada_id_opd)) !== false ? 'selected' : ''); ?>><?php echo e($nama); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <input class="form-control <?php $__errorArgs = ['kepada'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           name="kepada" id="kepada"
                                           type="text" value="<?php echo e($kepada); ?>"
                                           placeholder="Ketik Tujuan Lainnya jika lebih dari 1 gunakan tanda titik koma (;)">
                                    <?php $__errorArgs = ['kepada'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>

                                <div class="form-group">
                                    <label>Hal</label>

                                    <div class="input-group">
                                                        <span
                                                            class="input-group-prepend">
                                                        <label
                                                            class="input-group-text">
                                                        <i class="fa fa-align-right"></i></label>
                                                        </span>
                                        <input class="form-control <?php $__errorArgs = ['perihal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                               name="perihal" id="perihal"
                                               type="text" value="<?php echo e($perihal); ?>" autofocus>
                                    </div>
                                    <?php $__errorArgs = ['perihal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                            </div>
                            <div class="col-sm-6">


                                <div class="form-group">
                                    <label>Ditandatangani oleh</label>
                                    <div id="div_jenisttd">
                                        <select class="select_cari form-control" id="id_jenis_ttd_fk"
                                                name="id_jenis_ttd_fk"
                                                <?php if($status_sk=='final'): ?> disabled <?php endif; ?>>
                                            <?php $__currentLoopData = $listJenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option
                                                    value=<?php echo e($jenis->id_jenis_ttd); ?> <?php echo e($jenis->id_jenis_ttd==$id_jenis_ttd_fk ? 'selected' : ''); ?>><?php echo e($jenis->jenis_ttd.' - '.$jenis->nama_opd); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <?php $__errorArgs = ['id_jenis_ttd_fk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group" id="divBerkas">

                                    <label><?php if($berkas): ?> Ubah <?php else: ?>
                                            Unggah <?php endif; ?> Berkas</label>
                                    <input name="berkas" id="berkas" type="file"
                                           class="form-control"
                                           accept="application/pdf">
                                    <?php if($berkas): ?>
                                        <br/>
                                        <a href="<?php echo e(url('berkas/'.$berkas)); ?>" target="_blank">Lihat Berkas
                                            saat
                                            ini</a>
                                        <br/>
                                        <input type="checkbox" name="remove_berkas"
                                               value="<?php echo e($berkas); ?>">
                                        Hapus
                                        Berkas
                                        Ketika Disimpan
                                    <?php endif; ?>
                                    <?php $__errorArgs = ['berkas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p style="color:red">
                                        <?php echo e($message); ?>

                                    </p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <?php if($mode=='ubah' && $diisi_oleh=='perangkat_daerah'): ?>
                                    <div class="form-group">
                                        <label>Status</label>
                                        <br/>
                                        <div class="form-check form-check-inline mb-3">
                                            <input class="form-check-input" type="radio" id="statusradio1"
                                                   name="status_sk" value="draft" onchange="cekstatus()"
                                                   <?php if($status_sk=='draft'): ?> checked <?php endif; ?>>
                                            <label class="form-check-label" for="statusradio1">DRAFT</label>
                                        </div>
                                        <div class="form-check form-check-inline mb-3">
                                            <input class="form-check-input" type="radio" id="statusradio2"
                                                   name="status_sk" value="revisi" onchange="cekstatus()"
                                                   <?php if($status_sk=='revisi'): ?> checked <?php endif; ?>>
                                            <label class="form-check-label" for="statusradio2">REVISI</label>
                                        </div>
                                        <div class="form-check form-check-inline mb-3">
                                            <input class="form-check-input" type="radio" id="statusradio3"
                                                   name="status_sk" value="final" onchange="cekstatus()"
                                                   <?php if($status_sk=='final'): ?> checked <?php endif; ?>>
                                            <label class="form-check-label" for="statusradio3">FINAL</label>
                                        </div>

                                    </div>
                                <?php endif; ?>
                            </div>
                            <?php if($mode=='ubah' && $diisi_oleh=='perangkat_daerah'): ?>
                                <div class="col-sm-12" id="divcatatan">

                                    <div class="col-sm-12 mt-4 border-bottom-0">
                                        <div id="accordion">
                                            <div class="accordion">
                                                <div class="accordion-header" role="button" data-toggle="collapse"
                                                     data-target="#panel-body-1" aria-expanded="true">
                                                    <h4>Catatan dari Adpim</h4>
                                                </div>
                                                <div class="accordion-body collapse show" id="panel-body-1"
                                                     data-parent="#accordion">
                                                    <textarea
                                                        class="form-control"
                                                        name="catatan"
                                                        id="catatan"
                                                        style="min-height: 100px"><?php echo e($catatan); ?></textarea>
                                                </div>
                                            </div>
                                            <?php if($tanggapan!=null): ?>
                                                <div class="accordion">
                                                    <div class="accordion-header" role="button" data-toggle="collapse"
                                                         data-target="#panel-body-2">
                                                        <h4>Tanggapan terhadap catatan yang diberikan</h4>
                                                    </div>
                                                    <div class="accordion-body collapse show" id="panel-body-2"
                                                         data-parent="#accordion">
                                                        <p class="mb-0"><?php echo e($tanggapan); ?></p>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                </div>
                            <?php endif; ?>
                        </div>
                    </div>


                    <div class="card-footer text-right bg-whitesmoke">
                        <?php if($mode=='tambah'): ?>
                            <button type="reset" class="btn btn-secondary mr-2">Reset Form</button>
                        <?php endif; ?>
                        <button type="submit" class="btn btn-primary mr-2"><i class="mr-50 fa fa-save"></i>
                            <?php if($mode=='ubah'): ?> Simpan Perubahan <?php else: ?> Submit <?php endif; ?>
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(assetku('assets/modules/select2/dist/js/select2.full.min.js')); ?>"></script>
    <script src="<?php echo e(assetku('assets/modules/jquery-ui/jquery-ui.min.js')); ?>"></script>
    <script src="<?php echo e(assetku('magnific-popup/jquery.magnific-popup.min.js')); ?>"></script>
    <script src="<?php echo e(assetku('assets/modules/bootstrap-daterangepicker/daterangepicker.js')); ?>"></script>
    <script src="<?php echo e(assetku('assets/jshideyorix/general.js')); ?>"></script>

    <!--begin::Page Scripts(used by this page)-->
    <script type="text/javascript">
        <?php if(session('pesan_status')): ?>
        tampilPesan('<?php echo e(session('pesan_status.tipe')); ?>', '<?php echo e(session('pesan_status.desc')); ?>', '<?php echo e(session('pesan_status.judul')); ?>');
        <?php endif; ?>

        $(document).ready(function () {
            listTTD();
            cektujuan();
            cekstatus();
        });

        if (jQuery().daterangepicker) {
            if ($("#tgl_surat").length) {
                $('#tgl_surat').daterangepicker({
                    locale: {format: 'DD/MM/YYYY'},
                    singleDatePicker: true,
                });
            }
        }


        if (jQuery().select2) {
            $(".select_cari_placeholder").select2(
                {
                    placeholder: "Pilih Perangkat Daerah (bisa lebih dari 1 perangkat daerah)",
                    allowClear: true
                }
            );
        }

        function listTTD() {
            var kategori = 'basah'
            $.ajax({
                url: '<?php echo e(url('dashboard/get-list-ttd')); ?>',
                type: 'GET',
                data: {
                    kategori: kategori,
                    id_jenis_ttd_fk: '<?php echo e($id_jenis_ttd_fk); ?>',
                },
                success: function (res) {
                    $('select[name="id_jenis_ttd_fk"]').html(res);
                },
                error(res) {
                    console.log(res);
                }
            });
        }

        function cektujuan() {
            var cektujuan = $('input[name="tujuan"]:checked').val();
            // alert(cektujuan);
            if (cektujuan == 'luar') {
                $('#kepada').show();
                $('#divkepadaselect').addClass('d-none');
            } else if (cektujuan == 'dalam') {
                $('#kepada').hide();
                $('#divkepadaselect').removeClass('d-none');
            } else {
                //alert('hei');
                //$('#kepada').text('');
                $('#kepada').show();
                $('#divkepadaselect').removeClass('d-none');
            }
        }

        function cekstatus() {
            var cekstatus = $('input[name="status_sk"]:checked').val();
            // alert(cektujuan);
            if (cekstatus == 'draft') {
                $('#divcatatan').hide();

            } else {
                //alert('hei');
                //$('#kepada').text('');
                $('#divcatatan').show();
            }
        }

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('mylayouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\e-dokumen\resources\views/dashboard_page/suratkeluar/form.blade.php ENDPATH**/ ?>