<?php $__env->startSection('title', 'Data PPPK NIP '.$dataPPPK->nip); ?>
<?php $__env->startPush('vendor-css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-body">
            <div class="row">
                <div class="col-md-8 mt-2">
                    <div class="card">
                        <div class="card-header">
                            <h4>Data PPPK</h4>
                        </div>

                        <div class="card-body">

                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">Nama</label>

                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php echo e($dataPPPK->nama); ?>

                                    </label>
                                </div>
                            </div>

                            <hr class="mb-2">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">NIP</label>

                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php echo e($dataPPPK->nip); ?>

                                    </label>
                                </div>
                            </div>


                            <hr class="mb-2">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">Tempat Lahir</label>

                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php echo e($dataPPPK->tempat_lahir); ?>

                                    </label>
                                </div>
                            </div>


                            <hr class="mb-2">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">Tanggal Lahir</label>

                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php echo e(($dataPPPK->tgl_lahir)); ?>

                                    </label>
                                </div>
                            </div>

                            <hr class="mb-2">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">Gender</label>

                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php echo e(($dataPPPK->gender)); ?>

                                    </label>
                                </div>
                            </div>

                            <hr class="mb-2">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">Pendidikan</label>

                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php echo e($dataPPPK->pendidikan); ?>

                                    </label>
                                </div>
                            </div>

                            <hr class="mb-2">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">Tahun Lulus</label>

                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php echo e($dataPPPK->tahun); ?>

                                    </label>
                                </div>
                            </div>

                            <hr class="mb-2">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">Jabatan</label>

                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php echo e($dataPPPK->jabatan); ?>

                                    </label>
                                </div>
                            </div>

                            <hr class="mb-2">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">Golongan</label>

                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php echo e($dataPPPK->golongan); ?>

                                    </label>
                                </div>
                            </div>

                            <hr class="mb-2">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">Gaji</label>

                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php echo e('Rp. '.$dataPPPK->gaji); ?>

                                    </label>
                                </div>
                            </div>

                            <hr class="mb-2">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">Unit Kerja</label>

                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php echo e($dataPPPK->unker); ?>

                                    </label>
                                </div>
                            </div>

                            <hr class="mb-2">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">Tanggal Mulai</label>

                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php echo e($dataPPPK->tgl_mulai); ?>

                                    </label>
                                </div>
                            </div>

                            <hr class="mb-2">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">Tanggal Akhir</label>

                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php echo e($dataPPPK->tgl_akhir); ?>

                                    </label>
                                </div>
                            </div>


                        </div>

                    </div>

                </div>
                <div class="col-md-4 mt-2">
                    <div class="card">
                        <div class="card-body">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">Nomor</label>

                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php echo e($dataMaster->dokumen_nomor); ?>

                                    </label>
                                </div>
                            </div>
                            <hr class="mb-2">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">Tanggal</label>

                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php echo e(TanggalIndo2($dataMaster->dokumen_tanggal)); ?>

                                    </label>
                                </div>
                            </div>
                            <hr class="mb-2">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">Tentang</label>

                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php echo e($dataMaster->dokumen_hal); ?>

                                    </label>
                                </div>
                            </div>

                            <hr class="mb-2">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">dto</label>

                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php echo e($ttd); ?>

                                    </label>
                                </div>
                            </div>

                            <?php if(Auth::check()): ?>
                                <?php if(Auth::user()->id_opd_fk == cekIdBKD()): ?>
                                    <hr class="mb-2">
                                    <div class="col-sm-12">
                                        <div class="row mb-3">
                                            <a target="_blank"
                                               href="<?php echo e(url()->current()); ?>/download?nip=<?php echo e($dataPPPK->nip); ?>"
                                               class="btn btn-primary btn-block"><i class="fa fa-download"></i> Download</a>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>

    <!--end::Page Vendors-->
    <!--begin::Page Scripts(used by this page)-->
    <script src="<?php echo e(assetku('assets/jshideyorix/general.js')); ?>"></script>
    <script>
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('mylayouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\e-dokumen\resources\views/dashboard_page/pppk/detail.blade.php ENDPATH**/ ?>