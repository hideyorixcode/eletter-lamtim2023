<?php $__env->startSection('title', 'Form '.ucwords($mode).' Dokumen TTE '); ?>
<?php $__env->startPush('vendor-css'); ?>
    <link rel="stylesheet" href="<?php echo e(assetku('magnific-popup/magnific-popup.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(assetku('assets/modules/datatables/Select-1.2.4/css/select.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(assetku('assets/modules/select2/dist/css/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(assetku('assets//modules/bootstrap-daterangepicker/daterangepicker.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(assetku('freetransform/css/jquery.freetrans.css')); ?>"/>
    <style>
        .select_sm {
            height: 33.22222px !important;
            padding-bottom: 2px !important;
            padding-top: 2px !important;
            padding-right: 2px !important;
            padding-left: 2px !important;
        }

        #the-canvas {
            border: 1px solid black;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h1><?php echo e('Form '.ucwords($mode).' Dokumen TTE '); ?></h1>
            <div class="section-header-breadcrumb">
                <div class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></div>
                <div class="breadcrumb-item"><a href="<?php echo e(route('dokumen-tte')); ?>">Daftar Dokumen TTE </a></div>
                <div class="breadcrumb-item active"><?php echo e('Form '.ucwords($mode).' Dokumen TTE '); ?></div>
            </div>
        </div>
        <div class="section-body">
            <?php $__env->startComponent('components.infoubahversipdf'); ?>
            <?php if (isset($__componentOriginal58b2908f5ae323e311822e3d200e4e9f46667744)): ?>
<?php $component = $__componentOriginal58b2908f5ae323e311822e3d200e4e9f46667744; ?>
<?php unset($__componentOriginal58b2908f5ae323e311822e3d200e4e9f46667744); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
            <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <div class="alert-body">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
            <?php endif; ?>
            <form id="form" name="form" role="form" action="<?php echo e($action); ?>"
                  enctype="multipart/form-data" method="post" onsubmit="getbounds()">
                <?php echo e(csrf_field()); ?>

                <?php if($mode=='ubah'): ?>
                    <?php echo e(method_field('PUT')); ?>

                <?php endif; ?>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card card-primary">
                            <div class="card-body">
                                <div class="col-sm-12">
                                    <div class="row mb-3">
                                        <label class="col-sm-3 col-lg-3 col-form-label">No Dokumen</label>
                                        <div class="col-sm-4 col-lg-4">
                                            <div class="input-group">
                                 <span class="input-group-prepend">
                                 <label class="input-group-text">
                                 <i class="fa fa-list"></i></label>
                                 </span>
                                                <input class="form-control <?php $__errorArgs = ['no_dokumen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                       required="required" name="no_dokumen" id="no_dokumen"
                                                       type="text" value="<?php echo e($no_dokumen); ?>" autofocus>
                                            </div>
                                            <?php $__errorArgs = ['no_dokumen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label class="col-sm-3 col-lg-3 col-form-label">Tgl Dokumen</label>
                                        <div class="col-sm-4 col-lg-4">
                                            <div class="input-group">
                                 <span class="input-group-prepend">
                                 <label class="input-group-text">
                                 <i class="fa fa-calendar"></i></label>
                                 </span>
                                                <input class="form-control <?php $__errorArgs = ['tgl_dokumen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                       name="tgl_dokumen" id="tgl_dokumen"
                                                       type="text" value="<?php echo e($tgl_dokumen); ?>">
                                            </div>
                                            <?php $__errorArgs = ['tgl_dokumen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label class="col-sm-3 col-lg-3 col-form-label">Hal</label>
                                        <div class="col-sm-9 col-lg-9">
                                            <div class="input-group">
                                 <span
                                     class="input-group-prepend">
                                 <label
                                     class="input-group-text">
                                 <i class="fa fa-align-right"></i></label>
                                 </span>
                                                <input class="form-control <?php $__errorArgs = ['perihal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                       name="perihal" id="perihal"
                                                       type="text" value="<?php echo e($perihal); ?>">
                                            </div>
                                            <?php $__errorArgs = ['perihal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <div class="row mb-3">
                                        <label class="col-sm-3 col-lg-3 col-form-label">Perangkat Daerah</label>
                                        <div class="col-sm-9 col-lg-9">
                                            <?php if(in_array(Auth::user()->level, ['admin', 'superadmin'])): ?>
                                                <select class="select_cari form-control" id="id_opd_fk"
                                                        name="id_opd_fk">
                                                    <?php $__currentLoopData = $listPerangkat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nama => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option
                                                            value=<?php echo e($value); ?> <?php echo e($value==$id_opd_fk ? 'selected' : ''); ?>><?php echo e($nama); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            <?php else: ?>
                                                <input type="hidden" name="id_opd_fk" id="id_opd_fk"
                                                       value="<?php echo e(Auth::user()->id_opd_fk); ?>">
                                                <input type="text" readonly
                                                       class="form-control <?php $__errorArgs = ['id_opd_fk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                       value="<?php echo e(cek_opd(Auth::user()->id_opd_fk)->nama_opd); ?>">
                                            <?php endif; ?>
                                            <?php $__errorArgs = ['id_opd_fk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <div class="row mb-3">
                                        <label class="col-sm-3 col-lg-3 col-form-label">Ditandatangani oleh</label>
                                        <div class="col-sm-9 col-lg-9">

                                            <select class="select_cari form-control" id="id_jenis_ttd_fk"
                                                    name="id_jenis_ttd_fk"
                                                    <?php if($status_dokumen=='final'): ?> disabled <?php endif; ?>>
                                                <?php $__currentLoopData = $listJenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option
                                                        value=<?php echo e($jenis->id_jenis_ttd); ?> <?php echo e($jenis->id_jenis_ttd==$id_jenis_ttd_fk ? 'selected' : ''); ?>><?php echo e($jenis->jenis_ttd.' - '.$jenis->nama_opd); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php $__errorArgs = ['id_jenis_ttd_fk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        </div>
                                    </div>
                                    <div class="row mb-3" id="divBerkas"
                                         <?php if($status_dokumen=='final'): ?> style="display: none" <?php endif; ?>>
                                        <label class="col-sm-3 col-lg-3 col-form-label"><?php if($berkas): ?>
                                                Ubah
                                            <?php else: ?>
                                                Unggah
                                            <?php endif; ?> Berkas</label>
                                        <div class="col-sm-4 col-lg-4">
                                            <input name="berkas" id="berkas" type="file"
                                                   class="form-control"
                                                   accept="application/pdf">
                                            <?php if($berkas): ?>
                                                <br/>
                                                <a href="<?php echo e(url('berkas/temp/'.$berkas)); ?>" target="_blank">Lihat Berkas
                                                    saat
                                                    ini</a>
                                                <br/>
                                                <input type="checkbox" name="remove_berkas"
                                                       value="<?php echo e($berkas); ?>">
                                                Hapus
                                                Berkas
                                                Ketika Disimpan
                                            <?php endif; ?>
                                            <?php $__errorArgs = ['berkas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p style="color:red">
                                                <?php echo e($message); ?>

                                            </p>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php if($status_dokumen !='final'): ?>
                        <div class="col-lg-12" id="ttd-coor">

                            <div class="card card-warning">
                                <div class="card-body text-center">
                                    <h4>Atur Posisi Tanda Tangan Anda</h4>
                                    <input type="hidden" id="y" name="y">
                                    <input type="hidden" id="x" name="x">
                                    <input type="hidden" id="halaman" name="halaman">
                                    <input type="hidden" id="width-ttd" name="width">
                                    <input type="hidden" id="height-ttd" name="height">
                                    <img
                                        id="two"
                                        src="<?php if(isset($dataMaster->ttd)): ?> <?php echo e(url('uploads/' . $dataMaster->ttd->img_ttd)); ?> <?php else: ?> <?php echo e(assetku('assets/img/example-image.jpg')); ?> <?php endif; ?>"
                                        class="trans"
                                        width="100"
                                        height="100"
                                    />
                                    <div>

                                        <button type="button" class="btn-success btn" id="prev">Halaman Sebelumnya
                                        </button>
                                        <button type="button" class="btn btn-success" id="next">Halaman Selanjutnya
                                        </button>
                                        &nbsp; &nbsp;
                                        <span
                                        >Halaman: <span id="page_num"></span> / <span id="page_count"></span
                                            ></span>
                                    </div>
                                    <canvas style="margin-top: 10px;" id="the-canvas"></canvas>
                                </div>
                                <div class="card-footer text-right bg-whitesmoke">
                                    <?php if($mode=='tambah'): ?>
                                        <button type="reset" class="btn btn-secondary mr-2">Reset Form</button>
                                    <?php endif; ?>
                                    <button type="submit" class="btn btn-primary mr-2"><i class="mr-50 fa fa-save"></i>
                                        <?php if($mode=='ubah'): ?>
                                            Simpan Perubahan
                                        <?php else: ?>
                                            Submit
                                        <?php endif; ?>
                                    </button>
                                </div>
                            </div>

                        </div>
                <?php endif; ?>
            </form>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(assetku('assets/modules/select2/dist/js/select2.full.min.js')); ?>"></script>
    <script src="<?php echo e(assetku('assets/modules/jquery-ui/jquery-ui.min.js')); ?>"></script>
    <script src="<?php echo e(assetku('magnific-popup/jquery.magnific-popup.min.js')); ?>"></script>
    <script src="<?php echo e(assetku('assets/modules/bootstrap-daterangepicker/daterangepicker.js')); ?>"></script>
    <script src="<?php echo e(assetku('assets/jshideyorix/general.js')); ?>"></script>
    <script src="<?php echo e(assetku('freetransform/js/Matrix.js')); ?>"></script>
    <script src="<?php echo e(assetku('freetransform/js/jquery.freetrans.js')); ?>"></script>
    <script src="//mozilla.github.io/pdf.js/build/pdf.js"></script>
    <!--begin::Page Scripts(used by this page)-->
    <script type="text/javascript">
        <?php if(session('pesan_status')): ?>
        tampilPesan('<?php echo e(session('pesan_status.tipe')); ?>', '<?php echo e(session('pesan_status.desc')); ?>', '<?php echo e(session('pesan_status.judul')); ?>');
        <?php endif; ?>
        var pdfBlob = null;

        var pdfjsLib = window["pdfjs-dist/build/pdf"];
        pdfjsLib.GlobalWorkerOptions.workerSrc =
            "//mozilla.github.io/pdf.js/build/pdf.worker.js";
        var pdfDoc = null,
            pageNum = 1,
            pageRendering = false,
            pageNumPending = null,
            scale = 1,
            canvas = document.getElementById("the-canvas"),
            ctx = canvas.getContext("2d");

        if (jQuery().daterangepicker) {
            if ($("#tgl_dokumen").length) {
                $('#tgl_dokumen').daterangepicker({
                    locale: {format: 'DD/MM/YYYY'},
                    singleDatePicker: true,
                });
            }
        }

        document.getElementById("berkas").addEventListener("change", async function ({target}) {
            if (target.files && target.files.length) {
                pdfBlob = await convertFileToBase64(target.files[0]);
                showPDF(pdfBlob.split(';base64,')[1])
            }
        })

        function convertFileToBase64(file) {
            return new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.readAsDataURL(file);
                reader.onload = () => resolve(reader.result);
                reader.onerror = reject;
            });
        }

        function getbounds() {
            var b = $("#two").freetrans("getBounds");

            var pdf = getPositionXY(document.getElementById("the-canvas"));
            var widthTTD = b.xmin - pdf.left;
            var x = b.xmax - pdf.left;
            var y = pdf.bottom - b.ymin;
            var heightTTD = pdf.bottom - b.ymax;
            var halaman = pageNum;

            $('#y').val(y)
            $('#x').val(x)

            $('#width-ttd').val(widthTTD)
            $('#height-ttd').val(heightTTD)
            $('#halaman').val(halaman)

            //tampilPesan('info', 'Silahkan lanjutkan transaksi anda! sx: ' + x + ' y: ' + y, 'Berhasil mengambil koordinat');

        }

        /**
         * Get page info from document, resize canvas accordingly, and render page.
         * @param  num Page number.
         */
        function renderPage(num) {
            pageRendering = true;
            // Using promise to fetch the page
            pdfDoc.getPage(num).then(function (page) {
                var viewport = page.getViewport({scale: scale});

                canvas.height = viewport.height;
                canvas.width = viewport.width

                // Render PDF page into canvas context
                var renderContext = {
                    canvasContext: ctx,
                    viewport: viewport,
                };
                var renderTask = page.render(renderContext);

                // Wait for rendering to finish
                renderTask.promise.then(function () {
                    pageRendering = false;
                    if (pageNumPending !== null) {
                        // New page rendering is pending
                        renderPage(pageNumPending);
                        pageNumPending = null;
                    }
                });
            });

            // Update page counters
            document.getElementById("page_num").textContent = num;
        }

        function getPositionXY(element) {
            let box = element.getBoundingClientRect();
            return {
                top: box.top + window.pageYOffset,
                right: box.right + window.pageXOffset,
                bottom: box.bottom + window.pageYOffset,
                left: box.left + window.pageXOffset
            };
        }

        /**
         * If another page rendering in progress, waits until the rendering is
         * finised. Otherwise, executes rendering immediately.
         */
        function queueRenderPage(num) {
            if (pageRendering) {
                pageNumPending = num;
            } else {
                renderPage(num);
            }
        }

        /**
         * Displays previous page.
         */
        function onPrevPage() {
            if (pageNum <= 1) {
                return;
            }
            pageNum--;
            queueRenderPage(pageNum);
        }

        document.getElementById("prev").addEventListener("click", onPrevPage);

        /**
         * Displays next page.
         */
        function onNextPage() {
            if (pageNum >= pdfDoc.numPages) {
                return;
            }
            pageNum++;
            queueRenderPage(pageNum);
        }

        document.getElementById("next").addEventListener("click", onNextPage);

        /**
         * Asynchronously downloads PDF.
         */
        function showPDF(data) {
            var pdfData = atob(data)
            pdfjsLib.getDocument({data: pdfData}).promise.then(function (pdfDoc_) {
                pdfDoc = pdfDoc_;
                document.getElementById("page_count").textContent = pdfDoc.numPages;

                // Initial/first page rendering
                renderPage(pageNum);
            });
        }

        function initTransform() {
            $("#two").freetrans({
                x: 100,
                y: 100,
            });
        }

        $(function () {
            listTTD();
            //getImagettd();
            $('#ttd-coor').removeClass('d-none')
            initTransform()
        });

        function getImagettd() {
            var value = $('#id_jenis_ttd_fk').val();
            $.ajax({
                url: '<?php echo e(url('dashboard/get-ttd-image')); ?>',
                type: 'GET',
                data: {
                    id: value
                },
                success(res) {
                    $('#two').attr('src', res)
                    initTransform()
                },
                error(res) {

                }
            });
        }

        $('#id_jenis_ttd_fk').change(function () {
            getImagettd();
        })

        function listTTD() {
            //var kategori = $('#kategori_ttd').val();
            var kategori = 'elektronik';
            $.ajax({
                url: '<?php echo e(url('dashboard/get-list-ttd')); ?>',
                type: 'GET',
                data: {
                    kategori: kategori,
                    id_jenis_ttd_fk: '<?php echo e($id_jenis_ttd_fk); ?>',
                },
                success: function (res) {
                    $('select[name="id_jenis_ttd_fk"]').html(res);
                    getImagettd();
                },
                error(res) {
                    console.log(res);
                }
            });
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('mylayouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\e-dokumen\resources\views/dashboard_page/dokumentte/form.blade.php ENDPATH**/ ?>