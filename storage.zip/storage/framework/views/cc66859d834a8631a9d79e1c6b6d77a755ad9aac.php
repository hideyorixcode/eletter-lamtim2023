<div class="activity">
    <div class="activity-icon bg-<?php echo e($status); ?> text-white shadow-<?php echo e($status); ?>">
        <i class="<?php echo e($icon); ?>"></i>
    </div>
    <div class="activity-detail" style="width: 100%">
        <div class="mb-2">
                                                                       <span
                                                                           class="text-job text-primary"><?php echo e(TanggalIndowaktu($data->tgl_diterima)); ?></span>
        </div>

        <ul class="list-group">

            <?php if($data->status=='diteruskan'): ?>
                <li class="list-group-item">Diterima oleh :
                    <strong><?php echo e(cek_opd($data->penerima)->nama_opd); ?></strong> -
                    a.n. <?php echo e($data->nama_penerima); ?></li>
                <?php
                    $kepada = $data->kepada;

                ?>
                <?php if($kepada!=''): ?>
                    <?php $arr_kepada = explode (",", $kepada); ?>
                    <li class="list-group-item">Diteruskan kepada : <br/>
                        <?php $__currentLoopData = $arr_kepada; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            - <strong><?php echo e(cek_opd($x)->nama_opd); ?></strong><br/>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </li>
                <?php endif; ?>
                <?php if($data->melalui_id_opd): ?>
                    <li class="list-group-item">Melalui :
                        <strong><?php echo e(cek_opd($data->melalui_id_opd)->nama_opd); ?></strong>
                    </li>
                <?php endif; ?>
                <?php if($data->catatan_disposisi): ?>
                    <li class="list-group-item">Catatan
                        : <?php echo e($data->catatan_disposisi); ?></li>
                <?php endif; ?>
            <?php else: ?>
                <li class="list-group-item">Diolah oleh :
                    <strong><?php echo e(cek_opd($data->penerima)->nama_opd); ?></strong> -
                    a.n. <?php echo e($data->nama_penerima); ?></li>
            <?php endif; ?>

        </ul>


    </div>
</div>

<?php /**PATH D:\laragon\www\eletter\resources\views/dashboard_page/suratmasuk/tanggalisiuser.blade.php ENDPATH**/ ?>