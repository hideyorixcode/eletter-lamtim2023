<?php $__env->startSection('title', 'Settings Aplikasi'); ?>
<?php $__env->startPush('vendor-css'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>

    <section class="section">
        <div class="section-header">
            <h1>Konfigurasi Aplikasi</h1>
            <div class="section-header-breadcrumb">
                <div class="breadcrumb-item active"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></div>
                <div class="breadcrumb-item">Konfigurasi Aplikasi</div>
            </div>
        </div>

        <div class="section-body">
            <h2 class="section-title">Daftar Konfigurasi</h2>
            <p class="section-lead">
                Ubah Konfigurasi Aplikasi dan Simpan Perubahan nya
            </p>

            <div class="row mt-sm-4">
                <div class="col-12 col-md-12 col-lg-12">
                    <div class="card card-primary">

                        <!--begin::Card-->
                        <form id="form" method="post"
                              enctype="multipart/form-data"
                              action="<?php echo e(url('dashboard/update-settings')); ?>">
                            <!--begin::Form-->

                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('PUT')); ?>


                            <div class="card-body">
                                <?php if(count($errors) > 0): ?>
                                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                        <div class="alert-body">
                                            <ul>
                                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><?php echo e($error); ?></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">×</span>
                                        </button>
                                    </div>
                                <?php endif; ?>
                                <div class="row">
                                    <div class="col-lg-6">
                                        <?php
                                        $countTextfield = 0;
                                        foreach ($settingsText as $x) :
                                        ?>
                                        <input type="hidden" id="setting_Id" name="setting_Id[]"
                                               value="<?php echo e($x->setting_Id); ?>">
                                        <input type="hidden" id="setting_Type" name="setting_Type[]"
                                               value="<?php echo e($x->setting_Type); ?>">
                                        <?php if ($x->setting_Type == 'email') {
                                            $editor = 'email';
                                        } else if ($x->setting_Type == 'number') {
                                            $editor = 'number';
                                        } else {
                                            $editor = 'text';
                                        }
                                        ?>
                                        <div class="form-group row">
                                            <label
                                                class="col-xl-3 col-lg-3 col-form-label"><?php echo e($x->setting_Label); ?></label>
                                            <div class="col-lg-9 col-xl-9">
                                                <input
                                                    class="form-control <?php $__errorArgs = ['setting_Value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    name="setting_Value[]" id="<?php echo e($x->setting_Key); ?>" type="<?php echo e($editor); ?>"
                                                    value="<?php echo e($x->setting_Value); ?>" <?php if($countTextfield==0): ?> <?php echo e('autofocus'); ?> <?php endif; ?>/>
                                                <?php $__errorArgs = ['setting_Value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback">
                                                    <?php echo e($message); ?>

                                                </div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <?php
                                        $countTextfield++;
                                        endforeach;
                                        ?>
                                    </div>
                                    <!--end::Wizard Step 1-->
                                    <div class="col-lg-6">
                                        <?php
                                        $countTextarea = 0;
                                        foreach ($settingsTextarea as $i) :
                                        ?>
                                        <div class="form-group row">
                                            <label
                                                class="col-xl-3 col-lg-3 col-form-label"><?php echo e($i->setting_Label); ?></label>
                                            <div class="col-lg-9 col-xl-9">
                                                <input type="hidden" id="setting_Id" name="setting_Id[]"
                                                       value="<?php echo e($i->setting_Id); ?>">
                                                <input type="hidden" id="setting_Type" name="setting_Type[]"
                                                       value="<?php echo e($i->setting_Type); ?>">
                                                <textarea id="<?php echo e($i->setting_Key); ?>" name="setting_Value[]" rows="3"
                                                          class="form-control <?php $__errorArgs = ['setting_Value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e($i->setting_Value); ?></textarea>
                                                <?php $__errorArgs = ['setting_Value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback">
                                                    <?php echo e($message); ?>

                                                </div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <?php
                                        $countTextarea++;
                                        endforeach;
                                        ?>

                                        <hr/>

                                        <?php
                                        $countGambar = 0;
                                        foreach ($settingsGambar as $z) :
                                        ?>
                                        <div class="form-group row">
                                            <label
                                                class="col-xl-3 col-lg-3 col-form-label"><?php echo e($z->setting_Label); ?></label>
                                            <input type="hidden" id="idberkas" name="idberkas[]"
                                                   value="<?= $z->setting_Id ?>">
                                            <input type="hidden" id="setting_Typeberkas"
                                                   name="setting_Typeberkas[]"
                                                   value="<?= $z->setting_Type ?>">
                                            <input type="hidden" id="setting_Valueberkas"
                                                   name="setting_Valueberkas[]"
                                                   value="<?= $z->setting_Value ?>">
                                            <?php if ($z->setting_Type == 'gambar') {
                                                $filepilihan = 'image/*';
                                            } else if ($z->setting_Type == 'favicon') {
                                                $filepilihan = '.ico';
                                            } else {
                                                $filepilihan = '.pdf';
                                            }
                                            ?>
                                            <div class="row">
                                                <div class="col-xl-3 col-lg-3">
                                                    <img
                                                        src="<?php echo e($z->setting_Value ? url('uploads/' . $z->setting_Value) :url('uploads/blank.png')); ?>"
                                                        class="img-thumbnail img-preview_<?php echo e($countGambar); ?>">
                                                </div>
                                                <div class="col-xl-6 col-lg-6">
                                                    <div class="custom-file mb-3">
                                                        <input type="file" class="custom-file-input"
                                                               id="berkas_<?php echo e($countGambar); ?>"
                                                               name="berkas_<?php echo e($countGambar); ?>"
                                                               onchange="previewImg(<?php echo e($countGambar); ?>)"
                                                               accept="<?= $filepilihan ?>">
                                                        <label class="custom-file-label"
                                                               id="custom-file-label_<?php echo e($countGambar); ?>"
                                                               for="validatedCustomFile">Pilih
                                                            <?php echo e($z->setting_Label); ?>...</label>
                                                        <?php $__errorArgs = [$z->setting_Key];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <p style="color: red">
                                                            <?php echo e($message); ?>

                                                        </p>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                        $countGambar++;
                                        endforeach;
                                        ?>
                                    </div>


                                </div>
                            </div>
                            <div class="card-footer text-right">
                                <button class="btn btn-primary" type="submit"><i class="fas fa-save"></i> Simpan
                                    Perubahan
                                </button>
                            </div>
                        </form>
                    </div>

                </div>
            </div>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(assetku('assets/jshideyorix/general.js')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            <?php if(session('pesan_status')): ?>
            tampilPesan('<?php echo e(session('pesan_status.tipe')); ?>', '<?php echo e(session('pesan_status.desc')); ?>', '<?php echo e(session('pesan_status.judul')); ?>');
            <?php endif; ?>
        });

        function previewImg(id) {
            const logo = document.querySelector('#berkas_' + id);
            const logoLabel = document.querySelector('#custom-file-label_' + id);
            const logoPreview = document.querySelector('.img-preview_' + id);

            logoLabel.textContent = logo.files[0].name;

            const fileLogo = new FileReader();
            fileLogo.readAsDataURL(logo.files[0]);

            fileLogo.onload = function (e) {
                logoPreview.src = e.target.result;
            }
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('mylayouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\eletter\resources\views/dashboard_page/settings/index.blade.php ENDPATH**/ ?>