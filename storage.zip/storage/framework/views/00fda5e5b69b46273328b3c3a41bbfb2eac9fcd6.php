<?php $__env->startSection('title', 'Form '.ucwords($mode).' Surat Rahasia '); ?>
<?php $__env->startPush('vendor-css'); ?>
<link rel="stylesheet" href="<?php echo e(assetku('magnific-popup/magnific-popup.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(assetku('assets/modules/datatables/Select-1.2.4/css/select.bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(assetku('assets/modules/select2/dist/css/select2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(assetku('assets//modules/bootstrap-daterangepicker/daterangepicker.css')); ?>">
<style>
   .select_sm {
   height: 33.22222px !important;
   padding-bottom: 2px !important;
   padding-top: 2px !important;
   padding-right: 2px !important;
   padding-left: 2px !important;
   }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<section class="section">
   <div class="section-header">
      <h1><?php echo e('Form '.ucwords($mode).' Surat Rahasia '); ?></h1>
      <div class="section-header-breadcrumb">
         <div class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></div>
         <div class="breadcrumb-item"><a href="<?php echo e(route('surat-rahasia')); ?>">Daftar Surat Rahasia</a></div>
         <div class="breadcrumb-item active"><?php echo e('Form '.ucwords($mode).' Surat Rahasia '); ?></div>
      </div>
   </div>
   <div class="section-body">
      <form id="form" name="form" role="form" action="<?php echo e($action); ?>" enctype="multipart/form-data" method="post">
         <div class="row">
            <div class="col-sm-7">
               <div class="card">
                  <?php echo e(csrf_field()); ?>

                  <?php if($mode=='ubah'): ?>
                  <?php echo e(method_field('PUT')); ?>

                  <?php endif; ?>
                  <div class="card-body">
                     <div class="col-sm-12">
                        <div class="row mb-3">
                           <label class="col-sm-3 col-lg-3 col-form-label">Kode</label>
                           <div class="col-sm-9 col-lg-9">
                              <div class="input-group">
                                 <span class="input-group-prepend">
                                 <label class="input-group-text">
                                 <i class="fa fa-flag"></i></label>
                                 </span>
                                 <input class="form-control <?php $__errorArgs = ['kode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="kode" id="kode"
                                    type="text" value="<?php echo e($kode); ?>">
                                  <?php $__errorArgs = ['kode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                  <div class="invalid-feedback">
                                                                     <?php echo e($message); ?>

                                                                  </div>
                                                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              </div>

                           </div>
                        </div>
                        <div class="row mb-3">
                           <label class="col-sm-3 col-lg-3 col-form-label">Indek</label>
                           <div class="col-sm-9 col-lg-9">
                              <div class="input-group">
                                 <span
                                    class="input-group-prepend">
                                 <label
                                    class="input-group-text">
                                 <i class="fa fa-bell"></i></label>
                                 </span>
                                 <input class="form-control <?php $__errorArgs = ['indek'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="indek" id="indek"
                                    type="text" value="<?php echo e($indek); ?>">
                                  <?php $__errorArgs = ['indek'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="invalid-feedback">
                                                                   <?php echo e($message); ?>

                                                                </div>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              </div>

                           </div>
                        </div>
                        <div class="row mb-3">
                           <label class="col-sm-3 col-lg-3 col-form-label">No Surat</label>
                           <div class="col-sm-9 col-lg-9">
                              <div class="input-group">
                                 <span class="input-group-prepend">
                                 <label class="input-group-text">
                                 <i class="fa fa-list"></i></label>
                                 </span>
                                 <input class="form-control <?php $__errorArgs = ['no_surat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    required="required" name="no_surat" id="no_surat"
                                    type="text" value="<?php echo e($no_surat); ?>" autofocus>
                                  <?php $__errorArgs = ['no_surat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                               <div class="invalid-feedback">
                                                                  <?php echo e($message); ?>

                                                               </div>
                                                               <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              </div>

                           </div>
                        </div>
                        <div class="row mb-3">
                           <label class="col-sm-3 col-lg-3 col-form-label">Tgl Surat</label>
                           <div class="col-sm-9 col-lg-9">
                              <div class="input-group">
                                 <span class="input-group-prepend">
                                 <label class="input-group-text">
                                 <i class="fa fa-calendar"></i></label>
                                 </span>
                                 <input class="form-control <?php $__errorArgs = ['tgl_surat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="tgl_surat" id="tgl_surat"
                                    type="text" value="<?php echo e($tgl_surat); ?>">
                                  <?php $__errorArgs = ['tgl_surat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="invalid-feedback">
                                                                   <?php echo e($message); ?>

                                                                </div>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              </div>

                           </div>
                        </div>
                         <div class="row mb-3">
                            <label class="col-sm-3 col-lg-3 col-form-label">Lampiran</label>
                            <div class="col-sm-9 col-lg-9">
                               <div class="input-group">
                                  <span class="input-group-prepend">
                                  <label class="input-group-text">
                                  <i class="fa fa-sort-numeric-up"></i></label>
                                  </span>
                                  <input class="form-control <?php $__errorArgs = ['lampiran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                     name="lampiran" id="lampiran"
                                     type="number" value="<?php echo e($lampiran); ?>">
                                   <?php $__errorArgs = ['lampiran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="invalid-feedback">
                                                                   <?php echo e($message); ?>

                                                                </div>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                               </div>

                            </div>
                         </div>
                        <div class="row mb-3">
                           <label class="col-sm-3 col-lg-3 col-form-label">Dari</label>
                           <div class="col-sm-9 col-lg-9">
                              <div class="input-group">
                                 <span
                                    class="input-group-prepend">
                                 <label
                                    class="input-group-text">
                                 <i class="fa fa-user"></i></label>
                                 </span>
                                 <input class="form-control <?php $__errorArgs = ['dari'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="dari" id="dari"
                                    type="text" value="<?php echo e($dari); ?>">
                                  <?php $__errorArgs = ['dari'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                               <div class="invalid-feedback">
                                                                  <?php echo e($message); ?>

                                                               </div>
                                                               <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              </div>

                           </div>
                        </div>
                        <div class="row mb-3">
                           <label class="col-sm-3 col-lg-3 col-form-label">Kepada</label>
                           <div class="col-sm-9 col-lg-9">
                              <select class="select_cari form-control" id="kepada"
                                 name="kepada">
                              <?php $__currentLoopData = $listPerangkat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nama => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option
                              value=<?php echo e($value); ?> <?php echo e($value==$kepada ? 'selected' : ''); ?>><?php echo e($nama); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                              <?php $__errorArgs = ['kepada'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="invalid-feedback">
                                 <?php echo e($message); ?>

                              </div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                        </div>
                        <div class="row mb-3">
                           <label class="col-sm-3 col-lg-3 col-form-label">Hal</label>
                           <div class="col-sm-9 col-lg-9">
                              <div class="input-group">
                                 <span
                                    class="input-group-prepend">
                                 <label
                                    class="input-group-text">
                                 <i class="fa fa-align-right"></i></label>
                                 </span>
                                 <input class="form-control <?php $__errorArgs = ['perihal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="perihal" id="perihal"
                                    type="text" value="<?php echo e($perihal); ?>">
                                  <?php $__errorArgs = ['perihal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                               <div class="invalid-feedback">
                                                                  <?php echo e($message); ?>

                                                               </div>
                                                               <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              </div>

                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="col-sm-5">
               <div class="card">
                  <div class="card-body">
                     <div class="row mb-3">
                        <label class="col-sm-3 col-lg-3 col-form-label">Tgl Masuk</label>
                        <div class="col-sm-9 col-lg-9">
                           <div class="input-group">
                              <span
                                 class="input-group-prepend">
                              <label
                                 class="input-group-text">
                              <i class="fa fa-calendar"></i></label>
                              </span>
                              <input
                                 class="form-control datetimepickerindo <?php $__errorArgs = ['tgl_masuk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                 name="tgl_masuk" id="tgl_masuk" type="text" value="<?php echo e($tgl_masuk); ?>"/>
                               <?php $__errorArgs = ['tgl_masuk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                          <div class="invalid-feedback">
                                                             <?php echo e($message); ?>

                                                          </div>
                                                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>

                        </div>
                     </div>
                     <div class="row mb-3">
                        <label class="col-sm-3 col-lg-3 col-form-label">Nama Penerima</label>
                        <div class="col-sm-9 col-lg-9">
                           <div class="input-group">
                              <span
                                 class="input-group-prepend">
                              <label
                                 class="input-group-text">
                              <i class="fa fa-user"></i></label>
                              </span>
                              <input class="form-control <?php $__errorArgs = ['nama_penerima'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                 name="nama_penerima" id="nama_penerima"
                                 type="text" value="<?php echo e($nama_penerima); ?>">
                               <?php $__errorArgs = ['nama_penerima'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                          <div class="invalid-feedback">
                                                             <?php echo e($message); ?>

                                                          </div>
                                                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>

                        </div>
                     </div>
                     <div class="row mb-3">
                        <label class="col-sm-3 col-lg-3 col-form-label">Tujuan Disposisi</label>
                        <div class="col-sm-9 col-lg-9">
                           <select class="select_cari form-control" id="tujuan"
                              name="tujuan">
                           <?php $__currentLoopData = $listPimpinan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nama => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <option
                           value=<?php echo e($value); ?> <?php echo e($value==$tujuan ? 'selected' : ''); ?>><?php echo e($nama); ?></option>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </select>
                           <?php $__errorArgs = ['tujuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <div class="invalid-feedback">
                              <?php echo e($message); ?>

                           </div>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                     </div>
                     <div class="row mb-3">
                        <label class="col-sm-3 col-lg-3 col-form-label">Status</label>
                        <div class="col-sm-9 col-lg-9">
                           <input type="text" readonly value="DITERUSKAN" class="form-control">
                           <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <div class="invalid-feedback">
                              <?php echo e($message); ?>

                           </div>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                     </div>
                  </div>
                  <div class="card-footer text-right bg-whitesmoke">
                     <?php if($mode=='tambah'): ?>
                     <button type="reset" class="btn btn-secondary mr-2">Reset Form</button>
                     <?php endif; ?>
                     <button type="submit" class="btn btn-primary mr-2"><i class="mr-50 fa fa-save"></i>
                     <?php if($mode=='ubah'): ?> Simpan Perubahan <?php else: ?> Submit <?php endif; ?>
                     </button>
                  </div>
               </div>
            </div>
         </div>
      </form>
   </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(assetku('assets/modules/select2/dist/js/select2.full.min.js')); ?>"></script>
<script src="<?php echo e(assetku('assets/modules/jquery-ui/jquery-ui.min.js')); ?>"></script>
<script src="<?php echo e(assetku('magnific-popup/jquery.magnific-popup.min.js')); ?>"></script>
<script src="<?php echo e(assetku('assets/modules/bootstrap-daterangepicker/daterangepicker.js')); ?>"></script>
<script src="<?php echo e(assetku('assets/jshideyorix/general.js')); ?>"></script>
<!--begin::Page Scripts(used by this page)-->
<script type="text/javascript">
   <?php if(session('pesan_status')): ?>
   tampilPesan('<?php echo e(session('pesan_status.tipe')); ?>', '<?php echo e(session('pesan_status.desc')); ?>', '<?php echo e(session('pesan_status.judul')); ?>');
   <?php endif; ?>

   if (jQuery().daterangepicker) {
       if ($("#tgl_surat").length) {
           $('#tgl_surat').daterangepicker({
               locale: {format: 'DD/MM/YYYY'},
               singleDatePicker: true,
           });
       }
       // if ($("#tgl_masuk").length) {
       //     $('#tgl_masuk').daterangepicker({
       //         locale: {format: 'DD/MM/YYYY'},
       //         singleDatePicker: true,
       //     });
       // }

       if ($(".datetimepickerindo").length) {
           $('.datetimepickerindo').daterangepicker({
               locale: {format: 'DD/MM/YYYY HH:mm'},
               singleDatePicker: true,
               timePicker: true,
               timePicker24Hour: true,
           });
       }

   }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('mylayouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\e-dokumen\resources\views/dashboard_page/suratrahasia/form.blade.php ENDPATH**/ ?>