<div class="main-sidebar">
    <aside id="sidebar-wrapper">
        <div class="sidebar-brand">
            <a href="javascript:void(0)"><img src="<?php echo e(url('uploads/'.getSetting('logo'))); ?>" width="25px">
                | <?php echo e(getSetting('nama_app')); ?></a>
        </div>
        <div class="sidebar-brand sidebar-brand-sm">
            <a href="#"><img src="<?php echo e(url('uploads/'.getSetting('logo'))); ?>" width="25px"> </a>
        </div>
        <ul class="sidebar-menu">
            <li class="menu-header">Modul</li>
            <li class="<?php echo e(activeMenu('dashboard/surat-masuk')); ?>"><a class="nav-link"
                                                                   href="<?php echo e(url('dashboard/surat-masuk')); ?>"><i
                        class="fas fa-envelope"></i> <span>Surat Masuk</span></a></li>

        </ul>
    </aside>
</div>
<?php /**PATH D:\xampp\htdocs\e-dokumen\resources\views/mylayouts/menusespri.blade.php ENDPATH**/ ?>
