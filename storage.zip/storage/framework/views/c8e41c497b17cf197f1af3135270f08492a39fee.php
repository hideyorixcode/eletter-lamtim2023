<div id="container_grafik"></div>
<script>
    $(document).ready(function () {


        $('#container_grafik').highcharts({
            chart: {
                type: 'column'
            },
            title: {
                text: 'Statistik Bulanan Dokumen <?php echo e($namaperangkat); ?>'
            },
            subtitle: {
                text: 'Total Seluruh <?php echo e($tahun); ?>'
            },
            xAxis: {
                categories: [
                    'Jan',
                    'Feb',
                    'Mar',
                    'Apr',
                    'Mei',
                    'Jun',
                    'Jul',
                    'Aug',
                    'Sep',
                    'Okt',
                    'Nov',
                    'Desember'
                ],
                crosshair: true,
                allowDecimals: false
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Jumlah'
                }
            },
            tooltip: {
                headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                    '<td style="padding:0"><b>{point.y} </b></td></tr>',
                footerFormat: '</table>',
                shared: true,
                useHTML: true
            },
            plotOptions: {
                column: {
                    pointPadding: 0.2,
                    borderWidth: 0
                }
            },
            series: [
                {
                    name: 'Surat Masuk',
                    data: [<?php echo e($sm_01.','.$sm_02.','.$sm_03.','.$sm_04.','.$sm_05.','.$sm_06.','.$sm_07.','.$sm_08.','.$sm_09.','.$sm_10.','.$sm_11.','.$sm_12); ?>]

                }, {
                    name: 'Surat Langsung',
                    data: [<?php echo e($sl_01.','.$sl_02.','.$sl_03.','.$sl_04.','.$sl_05.','.$sl_06.','.$sl_07.','.$sl_08.','.$sl_09.','.$sl_10.','.$sl_11.','.$sl_12); ?>]

                }, {
                    name: 'Surat Rahasia',
                    data: [<?php echo e($sr_01.','.$sr_02.','.$sr_03.','.$sr_04.','.$sr_05.','.$sr_06.','.$sr_07.','.$sr_08.','.$sr_09.','.$sr_10.','.$sr_11.','.$sr_12); ?>]

                }, {
                    name: 'Surat Keluar',
                    data: [<?php echo e($sk_01.','.$sk_02.','.$sk_03.','.$sk_04.','.$sk_05.','.$sk_06.','.$sk_07.','.$sk_08.','.$sk_09.','.$sk_10.','.$sk_11.','.$sk_12); ?>]

                }
            ],
        });
    });

</script>
<?php /**PATH D:\laragon\www\e-dokumen\resources\views/dashboard_page/statistik.blade.php ENDPATH**/ ?>