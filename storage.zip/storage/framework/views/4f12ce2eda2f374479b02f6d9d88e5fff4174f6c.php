<?php $__env->startSection('title', 'Data SK PTHL'); ?>
<?php $__env->startPush('vendor-css'); ?>
    <link rel="stylesheet" href="<?php echo e(assetku('assets/modules/datatables/datatables.min.css')); ?>">
    <link rel="stylesheet"
          href="<?php echo e(assetku('assets/modules/datatables/DataTables-1.10.16/css/dataTables.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(assetku('assets/modules/datatables/Select-1.2.4/css/select.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(assetku('assets/modules/select2/dist/css/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(assetku('assets/modules/datatables/Buttons/css/buttons.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(assetku('assets//modules/bootstrap-daterangepicker/daterangepicker.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(assetku('magnific-popup/magnific-popup.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-body">
            <div class="row">
                <div class="col-md-12 mt-2">
                    <div class="card">
                        <div class="card-header">
                            <h4>Data SK PTHL</h4>
                        </div>

                        <div class="card-body">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">No SK</label>

                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php echo e($dataMaster->dokumen_nomor); ?>

                                    </label>
                                </div>
                            </div>
                            <hr class="mb-2">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">Tentang</label>

                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php echo e($dataMaster->dokumen_hal); ?>

                                    </label>
                                </div>
                            </div>

                            <hr class="mb-2">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">Penandatangan</label>

                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php echo e($ttd); ?>

                                    </label>
                                </div>
                            </div>

                        </div>

                    </div>

                </div>
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body">
                            <table class="table table-striped table-bordered" id="hideyori_datatable">
                                <thead>
                                <tr>
                                    <th>No Urut</th>
                                    <th>Nama</th>
                                    <th>NIK</th>
                                    <th>Tempat Lahir</th>
                                    <th>Tgl Lahir</th>
                                    <th>Pendidikan</th>
                                    <th>Tugas</th>
                                    <th>Instansi</th>
                                    <th></th>
                                </tr>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(assetku('assets/modules/datatables/datatables.min.js')); ?>"></script>
    <script
        src="<?php echo e(assetku('assets/modules/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(assetku('assets/modules/datatables/Select-1.2.4/js/dataTables.select.min.js')); ?>"></script>
    <script src="<?php echo e(assetku('assets/modules/select2/dist/js/select2.full.min.js')); ?>"></script>
    <script src="<?php echo e(assetku('assets/modules/jquery-ui/jquery-ui.min.js')); ?>"></script>
    <script src="<?php echo e(assetku('assets/modules/bootstrap-daterangepicker/daterangepicker.js')); ?>"></script>
    <!--end::Page Vendors-->
    <!--begin::Page Scripts(used by this page)-->
    <script src="<?php echo e(assetku('assets/jshideyorix/general.js')); ?>"></script>
    <script src="<?php echo e(assetku('assets/jshideyorix/mydatatable.js')); ?>"></script>
    <script src="<?php echo e(assetku('assets/jshideyorix/deletertable.js')); ?>"></script>
    <script src="<?php echo e(assetku('magnific-popup/jquery.magnific-popup.min.js')); ?>"></script>
    <?php echo $__env->make('components.buttonDatatables', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        $(document).ready(function () {
            table = $('#hideyori_datatable').DataTable({
                aLengthMenu: [
                    [10, 50, 100, -1],
                    [10, 50, 100, "All"]
                ],
                paging: true,
                processing: true,
                serverSide: true,
                responsive: true,
                autoWidth: false,
                pageLength : 100,
                language: {
                    search: "_INPUT_",
                    searchPlaceholder: "Cari dan Tekan Enter..."
                },
                
                ajax: {
                    url: "<?php echo e(url('data-sk-pthl')); ?>",
                    type: "GET",
                    data: function (d) {
                        d.dokumen_id = <?php echo e($dataMaster->dokumen_id); ?>;
                    }
                },
                columns: [

                    {data: 'pthl_urut', name: 'pthl_urut', responsivePriority: -1},
                    {data: 'pthl_nama', name: 'pthl_nama'},
                    {data: 'pthl_nik', name: 'pthl_nik'},
                    {data: 'pthl_tempat_lahir', name: 'pthl_tempat_lahir'},
                    {data: 'pthl_tgl_lahir', name: 'pthl_tgl_lahir'},
                    {data: 'pthl_pendidikan', name: 'pthl_pendidikan'},
                    {data: 'pthl_tugas', name: 'pthl_tugas'},
                    {data: 'pthl_opd', name: 'pthl_opd'},
                    {
                        data: 'pthl_qr',
                        name: 'pthl_qr',
                        orderable: false,
                        searchable: false,
                        className: 'text-center'
                    },
                ],

                rowCallback: function (row, data, index) {
                    cellValue = data['pthl_id'];
                    // console.log(cellValue);
                    var html = $(row);
                    if (array_data.includes(cellValue, 0)) {
                        var input = html.find('input[type=checkbox]').prop('checked', 'checked')
                    }
                },
                drawCallback: function () {
                    $('.data-check').on('change', function () {
                        console.log($(this).val());
                        if ($(this).is(':checked')) {
                            array_data.push($(this).val())
                        } else {
                            var index = array_data.indexOf($(this).val());
                            if (index !== -1) {
                                array_data.splice(index, 1);
                            }
                        }
                    });
                    var totalData = table.page.info().recordsTotal;
                    initMagnific();
                },
                "error": function (xhr, error, thrown) {
                    console.log("Error occurred!");
                    console.log(xhr, error, thrown);
                }
            });

            $('#hideyori_datatable_filter input').unbind();
            $('#hideyori_datatable_filter input').bind('keyup', function (e) {
                if (e.keyCode == 13) {
                    table.search(this.value).draw();
                }
            });

            $('#hideyori_datatable').on('error.dt', function (e, settings, techNote, message) {
                console.log('An error has been reported by DataTables: ', message);
            }).DataTable();

            table.on('responsive-display', function (e, datatable, row, showHide, update) {
                initMagnific();
            });


        });

        function initMagnific() {
            $('.image-popup-no-margins').magnificPopup({
                type: 'image',
                closeOnContentClick: true,
                fixedContentPos: true,
                mainClass: 'mfp-no-margins mfp-with-zoom', // class to remove default margin from left and right side
                image: {
                    verticalFit: true
                },
            });
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('mylayouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\e-dokumen\resources\views/dashboard_page/pthl/show.blade.php ENDPATH**/ ?>