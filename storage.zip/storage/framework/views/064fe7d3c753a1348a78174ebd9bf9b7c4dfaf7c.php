<div class="main-sidebar">
    <aside id="sidebar-wrapper">
        <div class="sidebar-brand">
            <a href="javascript:void(0)"><img src="<?php echo e(url('uploads/'.getSetting('logo'))); ?>" width="25px">
                | <?php echo e(getSetting('nama_app')); ?></a>
        </div>
        <div class="sidebar-brand sidebar-brand-sm">
            <a href="#"><img src="<?php echo e(url('uploads/'.getSetting('logo'))); ?>" width="25px"> </a>
        </div>
        <ul class="sidebar-menu">
            <li class="menu-header">Modul</li>
            <li class="<?php echo e(activeSegment('dashboard')); ?>"><a class="nav-link" href="<?php echo e(route('dashboard')); ?>"><i
                        class="fas fa-home"></i> <span>Dashboard</span></a></li>

            <li class="nav-item dropdown <?php echo e(activeMenu('dashboard/surat-masuk')); ?> <?php echo e(activeMenu('dashboard/surat-langsung')); ?> <?php echo e(activeMenu('dashboard/surat-rahasia')); ?> <?php echo e(activeMenu('dashboard/surat-masuk-pejabat')); ?> <?php echo e(activeMenu('dashboard/surat-masuk-instansi')); ?>">
                <a href="#" class="nav-link has-dropdown"><i
                        class="fas fa-inbox"></i><span>Surat Masuk</span></a>
                <ul class="dropdown-menu">
                    <li class="<?php echo e(activeMenu('dashboard/surat-masuk')); ?>"><a class="nav-link"
                                                                           href="<?php echo e(url('dashboard/surat-masuk')); ?>">Pimpinan</a>
                    </li>
                    <li class="<?php echo e(activeMenu('dashboard/surat-masuk-instansi')); ?>"><a class="nav-link"
                                                                                    href="<?php echo e(url('dashboard/surat-masuk-instansi')); ?>">Instansi</a>
                    </li>
                    <li class="<?php echo e(activeMenu('dashboard/surat-masuk-pejabat')); ?>"><a class="nav-link"
                                                                                   href="<?php echo e(url('dashboard/surat-masuk-pejabat')); ?>">Intern</a>
                    </li>
                </ul>
            </li>

            <li class="nav-item dropdown <?php echo e(activeMenu('dashboard/surat-keluar')); ?> <?php echo e(activeMenu('dashboard/surat-keluar-tte')); ?>">
                <a href="#" class="nav-link has-dropdown"><i
                        class="fas fa-paper-plane"></i><span>Surat Keluar</span></a>
                <ul class="dropdown-menu">
                    <li class="<?php echo e(activeMenu('dashboard/surat-keluar')); ?>"><a class="nav-link"
                                                                            href="<?php echo e(url('dashboard/surat-keluar')); ?>">Tanda
                            Tangan Basah</a>
                    </li>
                    <li class="<?php echo e(activeMenu('dashboard/surat-keluar-tte')); ?>"><a class="nav-link"
                                                                                href="<?php echo e(url('dashboard/surat-keluar-tte')); ?>">Tanda
                            Tangan Elektronik</a>
                    </li>

                </ul>
            </li>

            <li class="<?php echo e(activeMenu('dashboard/dokumen-tte')); ?>"><a class="nav-link"
                                                                   href="<?php echo e(url('dashboard/dokumen-tte')); ?>"><i
                        class="fas fa-file-code"></i> <span>Dokumen TTE</span></a></li>

            <li class="<?php echo e(activeMenu('dashboard/verifikasi-tte')); ?>"><a class="nav-link"
                                                                      href="<?php echo e(url('dashboard/verifikasi-tte')); ?>"><i
                        class="fas fa-check-square"></i> <span>Verifikasi TTE</span></a></li>


            <?php if(Auth::user()->id_opd_fk==cekIdBKD()): ?>
                <li class="<?php echo e(activeMenu('dashboard/pns/jabatan-pelaksana')); ?>"><a class="nav-link"
                                                                                 href="<?php echo e(url('dashboard/pns/jabatan-pelaksana')); ?>"><i
                            class="fas fa-id-card-alt"></i> <span>SK PNS Pelaksana</span></a></li>
                <li class="<?php echo e(activeMenu('dashboard/pppk')); ?>"><a class="nav-link"
                                                                                 href="<?php echo e(url('dashboard/pppk')); ?>"><i
                            class="fas fa-id-card"></i> <span>PPPK</span></a></li>
                <li class="<?php echo e(activeMenu('dashboard/pthl')); ?>"><a class="nav-link"
                                                                href="<?php echo e(url('dashboard/pthl')); ?>"><i
                            class="far fa-credit-card"></i> <span>SK PTHL</span></a></li>
                <li class="<?php echo e(activeMenu('dashboard/pthl/group-instansi')); ?>"><a class="nav-link"
                                                                               href="<?php echo e(url('dashboard/pthl/group-instansi')); ?>"><i
                            class="far fa-building"></i> <span>SK PTHL BY INSTANSI</span></a></li>
            <?php endif; ?>


        </ul>
    </aside>
</div>
<?php /**PATH D:\xampp\htdocs\e-dokumen\resources\views/mylayouts/menusespri.blade.php ENDPATH**/ ?>