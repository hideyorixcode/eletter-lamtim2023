<?php $__env->startSection('title', 'PTHL'); ?>
<?php $__env->startPush('vendor-css'); ?>
    <!--begin::Page Vendors Styles(used by this page)-->
    <link rel="stylesheet" href="<?php echo e(assetku('assets/modules/datatables/datatables.min.css')); ?>">
    <link rel="stylesheet"
          href="<?php echo e(assetku('assets/modules/datatables/DataTables-1.10.16/css/dataTables.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(assetku('assets/modules/datatables/Select-1.2.4/css/select.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(assetku('assets/modules/select2/dist/css/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(assetku('assets/modules/datatables/Buttons/css/buttons.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(assetku('assets//modules/bootstrap-daterangepicker/daterangepicker.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(assetku('magnific-popup/magnific-popup.min.css')); ?>">
    <!--end::Page Vendors Styles-->
<?php $__env->stopPush(); ?>
<?php $__env->startPush('library-css'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <!--begin::Card-->

    <section class="section">
        <div class="section-header">
            <h1>PTHL</h1>
            <?php if(in_array(Auth::user()->level, ['admin', 'superadmin'])): ?>
                <div class="section-header-button">
                    <a href="javascript:add()"
                       class="btn btn-primary btn-sm"><i
                            class="fa fa-plus mr-50"></i>
                        Tambah
                    </a>
                </div>
            <?php endif; ?>
            <div class="section-header-breadcrumb">
                <div class="breadcrumb-item active"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></div>
                <div class="breadcrumb-item">PTHL</div>
            </div>
        </div>

        <div class="section-body">

            <div class="row">

                <div class="col-md-12">
                    <div class="alert alert-warning">
                        Klik pada Gambar QRCode untuk memperbesar
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="card mb-3">
                        <div class="card-body">
                            <div class="row">

                                <div class="col-lg-6">
                                    <div class="form-row mb-3">
                                        <div class="col-lg-12">
                                            <label>Nomor Dokumen :</label>
                                            <select class="select_cari form-control" id="select_document"
                                                    name="select_document">
                                                <?php $__currentLoopData = $listDokumen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option
                                                        value="<?php echo e($x->dokumen_id.'|'.url('list-pthl/'.$x->dokumen_seo)); ?>"><?php echo e($x->dokumen_nomor); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-6" style="display: none">
                                    <div class="form-row mb-3">
                                        <div class="col-lg-12">
                                            <label>Link :</label>
                                            <br/>
                                            <a href="" id="linkdokumen" target="_blank">Hei</a>
                                        </div>
                                    </div>
                                </div>


                                <div class="col-lg-12 text-right">
                                    <button class="btn btn-outline-info btn-sm" onclick="reloadTable()"
                                            type="button"
                                            id="btnubah">
                                        <i class="fa fa-undo"></i> Saring Data
                                    </button>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body">
                            <table class="table table-striped table-bordered" id="hideyori_datatable">
                                <thead>
                                <tr>
                                    <?php if(in_array(Auth::user()->level, ['admin', 'superadmin'])): ?>
                                        <th><input type="checkbox" id="check-all"></th>
                                    <?php endif; ?>
                                    <th>No Urut</th>
                                    <th>Nama</th>
                                    <th>NIK</th>
                                    <th>Tempat Lahir</th>
                                    <th>Tgl Lahir</th>
                                    <th>Pendidikan</th>
                                    <th>Tugas</th>
                                    <th>Instansi</th>
                                    <th>QR</th>

                                        <th>Actions</th>

                                </tr>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>
                        </div>


                        <div class="card-footer">
                            <div class="row">
                                <?php if(in_array(Auth::user()->level, ['admin', 'superadmin'])): ?>
                                    <div class="col-lg-6  col-xl-6 col-6 text-left" id="div_opsi"
                                         style="display: none">
                                        <div class="dropdown d-inline">
                                            <button class="btn btn-dark dropdown-toggle" type="button"
                                                    id="dropdownMenuButton2"
                                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                Pilih Opsi
                                            </button>
                                            <div class="dropdown-menu">
                                                <a class="dropdown-item has-icon" href="javascript:bulkQR()"><i
                                                        class="fa fa-qrcode text-success"></i> Bubuhi QR</a>
                                                <a class="dropdown-item has-icon" href="javascript:bulkDelete()"><i
                                                        class="fa fa-trash text-danger"></i> Hapus</a>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                <div class="col-lg-6  col-xl-6 col-6 text-right" id="div_ekspor"
                                     style="display: none">
                                </div>
                            </div>
                        </div>

                        <!--begin::Dropdown-->

                    </div>
                </div>
            </div>


        </div>
    </section>

    <?php if(in_array(Auth::user()->level, ['admin', 'superadmin','sespri'])): ?>
        <!-- Modal -->
        <div
            class="modal fade"
            id="modal_form"
            
            role="dialog"
            aria-labelledby="exampleModalScrollableTitle"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered modal-lg" role="document">
                <div class="modal-content">
                    <form class="form form-horizontal" id="form" name="form" method="post"
                          enctype="multipart/form-data" action="javascript:save();">
                        <div class="modal-header bg-dark text-white" style="padding-top: 10px; padding-bottom: 10px">
                            <h6 class="modal-title" id="judul">Modal title</h6>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>

                        <div class="modal-body" style="max-height: 400px;">

                            <div class="row">

                                <div class="col-12">
                                    <div class="form-group row">
                                        <div class="col-sm-3 col-form-label">
                                            <label>Pilih Nomor Dokumen</label>
                                        </div>
                                        <div class="col-sm-9">
                                            <select class="select_cari form-control" id="dokumen_id"
                                                    name="dokumen_id">
                                                <?php $__currentLoopData = $listDokumen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option
                                                        value=<?php echo e($x->dokumen_id); ?>><?php echo e($x->dokumen_nomor); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <div class="invalid-feedback" id="error_dokumen_id">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-group row">
                                        <div class="col-sm-3 col-form-label">
                                            <label>Nomor Urut</label>
                                        </div>
                                        <div class="col-sm-9">
                                            <input type="hidden" id="pthl_id" class="form-control"
                                                   name="pthl_id">
                                            <input type="text" id="pthl_urut" class="form-control"
                                                   name="pthl_urut">
                                            <div class="invalid-feedback" id="error_pthl_urut">
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-12">
                                    <div class="form-group row">
                                        <div class="col-sm-3 col-form-label">
                                            <label>Nama</label>
                                        </div>
                                        <div class="col-sm-9">
                                            <input type="text" id="pthl_nama" class="form-control"
                                                   name="pthl_nama">
                                            <div class="invalid-feedback" id="error_pthl_nama">
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-12">
                                    <div class="form-group row">
                                        <div class="col-sm-3 col-form-label">
                                            <label>NIK</label>
                                        </div>
                                        <div class="col-sm-9">
                                            <input type="text" id="pthl_nik" class="form-control"
                                                   name="pthl_nik">
                                            <div class="invalid-feedback" id="error_pthl_nik">
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-12">
                                    <div class="form-group row">
                                        <div class="col-sm-3 col-form-label">
                                            <label>Tempat Lahir</label>
                                        </div>
                                        <div class="col-sm-9">
                                            <input type="text" id="pthl_tempat_lahir" class="form-control"
                                                   name="pthl_tempat_lahir">
                                            <div class="invalid-feedback" id="error_pthl_tempat_lahir">
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-12">
                                    <div class="form-group row">
                                        <div class="col-sm-3 col-form-label">
                                            <label>Tanggal Lahir</label>
                                        </div>
                                        <div class="col-sm-9">
                                            <input type="text" id="pthl_tgl_lahir" class="form-control"
                                                   name="pthl_tgl_lahir">
                                            <div class="invalid-feedback" id="error_pthl_tgl_lahir">
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-12">
                                    <div class="form-group row">
                                        <div class="col-sm-3 col-form-label">
                                            <label>Pendidikan</label>
                                        </div>
                                        <div class="col-sm-9">
                                            <input type="text" id="pthl_pendidikan" class="form-control"
                                                   name="pthl_pendidikan">
                                            <div class="invalid-feedback" id="error_pthl_pendidikan">
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-12">
                                    <div class="form-group row">
                                        <div class="col-sm-3 col-form-label">
                                            <label>Tugas</label>
                                        </div>
                                        <div class="col-sm-9">
                                            <input type="text" id="pthl_tugas" class="form-control"
                                                   name="pthl_tugas">
                                            <div class="invalid-feedback" id="error_pthl_tugas">
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-12">
                                    <div class="form-group row">
                                        <div class="col-sm-3 col-form-label">
                                            <label>Instansi</label>
                                        </div>
                                        <div class="col-sm-9">
                                            <input type="text" id="pthl_opd" class="form-control"
                                                   name="pthl_opd">
                                            <div class="invalid-feedback" id="error_pthl_opd">
                                            </div>
                                        </div>
                                    </div>
                                </div>


                            </div>
                        </div>
                        <div class="modal-footer bg-whitesmoke">
                            <button type="submit" id="btnsave"
                                    class="btn btn-primary mr-1 waves-effect waves-float waves-light">
                                <i class="fa fa-save"></i> <span id="teksSimpan"> Submit</span>
                            </button>
                            <button type="button" id="btnbatal" onclick="add()"
                                    class="btn btn-outline-secondary waves-effect"
                                    style="display: none">
                                Batal
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(assetku('assets/modules/datatables/datatables.min.js')); ?>"></script>
    <script
        src="<?php echo e(assetku('assets/modules/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(assetku('assets/modules/datatables/Select-1.2.4/js/dataTables.select.min.js')); ?>"></script>
    <script src="<?php echo e(assetku('assets/modules/select2/dist/js/select2.full.min.js')); ?>"></script>
    <script src="<?php echo e(assetku('assets/modules/jquery-ui/jquery-ui.min.js')); ?>"></script>
    <script src="<?php echo e(assetku('assets/modules/bootstrap-daterangepicker/daterangepicker.js')); ?>"></script>
    <!--end::Page Vendors-->
    <!--begin::Page Scripts(used by this page)-->
    <script src="<?php echo e(assetku('assets/jshideyorix/general.js')); ?>"></script>
    <script src="<?php echo e(assetku('assets/jshideyorix/mydatatable.js')); ?>"></script>
    <script src="<?php echo e(assetku('assets/jshideyorix/deletertable.js')); ?>"></script>
    <script src="<?php echo e(assetku('magnific-popup/jquery.magnific-popup.min.js')); ?>"></script>
    <?php echo $__env->make('components.buttonDatatables', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--end::Page Vendors-->
    <!--begin::Page Scripts(used by this page)-->
    <script type="text/javascript">

        <?php if(session('pesan_status')): ?>
        tampilPesan('<?php echo e(session('pesan_status.tipe')); ?>', '<?php echo e(session('pesan_status.desc')); ?>', '<?php echo e(session('pesan_status.judul')); ?>');
        <?php endif; ?>

        function initMagnific() {
            $('.image-popup-no-margins').magnificPopup({
                type: 'image',
                closeOnContentClick: true,
                fixedContentPos: true,
                mainClass: 'mfp-no-margins mfp-with-zoom', // class to remove default margin from left and right side
                image: {
                    verticalFit: true
                },
            });
        }

        function getlink() {
            let link = $("#select_document").val();
            const mylink = link.split("|");
            $("#linkdokumen").attr('href', mylink[1]);
            $("#linkdokumen").text(mylink[1]);
        }

        $(document).ready(function () {
            getlink();
            table = $('#hideyori_datatable').DataTable({
                aLengthMenu: [
                    [10, 50, 100, -1],
                    [10, 50, 100, "All"]
                ],
                paging: true,
                processing: true,
                serverSide: true,
                responsive: true,
                autoWidth: false,
                pageLength:100,
                language: {
                    search: "_INPUT_",
                    searchPlaceholder: "Cari dan Tekan Enter..."
                },
                
                ajax: {
                    url: "<?php echo e(route('pthl.data')); ?>",
                    type: "GET",
                    data: function (d) {
                        d.dokumen_id = $("#select_document").val();
                    }
                },
                columns: [
                        <?php if(in_array(Auth::user()->level, ['admin', 'superadmin'])): ?>
                    {
                        data: 'checkbox',
                        name: 'checkbox',
                        orderable: false,
                        searchable: false,
                        className: 'text-center',
                        responsivePriority: -1
                    },
                        <?php endif; ?>
                    {
                        data: 'pthl_urut', name: 'pthl_urut', responsivePriority: -1
                    },
                    {data: 'pthl_nama', name: 'pthl_nama'},
                    {data: 'pthl_nik', name: 'pthl_nik'},
                    {data: 'pthl_tempat_lahir', name: 'pthl_tempat_lahir'},
                    {data: 'pthl_tgl_lahir', name: 'pthl_tgl_lahir'},
                    {data: 'pthl_pendidikan', name: 'pthl_pendidikan'},
                    {data: 'pthl_tugas', name: 'pthl_tugas'},
                    {data: 'pthl_opd', name: 'pthl_opd'},
                    {
                        data: 'pthl_qr',
                        name: 'pthl_qr',
                        orderable: false,
                        searchable: false,
                        className: 'text-center'
                    },

                    {
                        data: 'action', name: 'action', orderable: false, searchable: false, className: 'text-center'
                    },

                ],

                rowCallback: function (row, data, index) {
                    cellValue = data['pthl_id'];
                    // console.log(cellValue);
                    var html = $(row);
                    if (array_data.includes(cellValue, 0)) {
                        var input = html.find('input[type=checkbox]').prop('checked', 'checked')
                    }
                },
                drawCallback: function () {
                    $('.data-check').on('change', function () {
                        console.log($(this).val());
                        if ($(this).is(':checked')) {
                            array_data.push($(this).val())
                        } else {
                            var index = array_data.indexOf($(this).val());
                            if (index !== -1) {
                                array_data.splice(index, 1);
                            }
                        }
                    });
                    var totalData = table.page.info().recordsTotal;
                    if (totalData > 0) {
                        <?php if(in_array(Auth::user()->level, ['admin', 'superadmin'])): ?>
                        $('#div_opsi').show();
                        $('#check-all').show();
                        <?php endif; ?>
                        $('#div_ekspor').html('');
                        $('#div_ekspor').show();


                        <?php if(in_array(Auth::user()->level, ['admin', 'superadmin'])): ?>
                        exporni = '1,2,3,4,5,6,7,8,9';
                        <?php else: ?>
                        exporni = '0,1,2,3,4,5,6,7';
                        <?php endif; ?>


                        var buttons_dom = new $.fn.dataTable.Buttons(table, {
                            buttons: [
                                {
                                    extend: 'print',
                                    text: 'Print',
                                    title: 'PTHL',
                                    customize: function (win) {
                                        $(win.document.body).find('h1').css('text-align', 'center');
                                    },
                                    exportOptions: {
                                        columns: exporni
                                        //columns : '0,1,2,3,4,5,6,7,8'
                                    }
                                },
                                {
                                    extend: 'copyHtml5',
                                    text: 'Copy',
                                    title: 'PTHL',
                                    exportOptions: {
                                        //columns: ':visible'
                                        columns: exporni
                                    }
                                },
                                {
                                    extend: 'excelHtml5',
                                    text: 'Excel',
                                    title: 'PTHL',
                                    exportOptions: {
                                        //columns: ':visible'
                                        columns: exporni
                                    }
                                },

                            ]
                        }).container().appendTo($('#div_ekspor'));

                    } else {
                        <?php if(in_array(Auth::user()->level, ['admin', 'superadmin'])): ?>
                        $('#div_opsi').hide();
                        <?php endif; ?>
                        $('#div_ekspor').hide();
                        $('#check-all').hide();
                    }
                    initMagnific();
                    <?php if(in_array(Auth::user()->level, ['admin', 'superadmin','sespri'])): ?>
                    initClick();
                    <?php endif; ?>
                },
                "error": function (xhr, error, thrown) {
                    console.log("Error occurred!");
                    console.log(xhr, error, thrown);
                }
            });

            $('#hideyori_datatable_filter input').unbind();
            $('#hideyori_datatable_filter input').bind('keyup', function (e) {
                if (e.keyCode == 13) {
                    table.search(this.value).draw();
                }
            });

            $('#hideyori_datatable').on('error.dt', function (e, settings, techNote, message) {
                console.log('An error has been reported by DataTables: ', message);
            }).DataTable();

            table.on('responsive-display', function (e, datatable, row, showHide, update) {
                initMagnific();
                <?php if(in_array(Auth::user()->level, ['admin', 'superadmin'])): ?>
                initClick();
                <?php endif; ?>
            });


        });

        <?php if(in_array(Auth::user()->level, ['admin', 'superadmin'])): ?>
        function deleteData(paramId) {
            var url = '<?php echo e(url('dashboard/pthl/delete/')); ?>';
            deleteDataTable(paramId, url);
        }


        function bulkDelete() {
            var url = '<?php echo e(url('dashboard/pthl/bulkDelete/')); ?>';
            bulkDeleteTable(url)
        }

        function bulkQR() {
            var urlnya = '<?php echo e(url('dashboard/pthl/bulkQR/')); ?>';
            var list_id = [];
            $(".data-check:checked").each(function () {
                list_id.push(this.value);
            });
            var token = $('meta[name="csrf-token"]').attr('content');
            if (list_id.length > 0) {
                Swal.fire({
                    title: 'Yakin akan membubuhi QR : ' + list_id.length + ' data yg telah dipilih ?',
                    text: "Cek kembali data anda sebelum dibubuhi QR",
                    icon: 'warning',
                    showCancelButton: true,
                    reverseButtons: true,
                    confirmButtonText: 'Ya',
                    cancelButtonText: 'Tidak',
                }).then((result) => {
                    if (result.value) {
                        $.ajax({
                            headers: {
                                'X-CSRF-TOKEN': token
                            },
                            url: urlnya,
                            type: "POST",
                            data: {
                                id: list_id,
                            },
                            dataType: "JSON",
                            success: function (data) {
                                if (data.status) {
                                    reloadTable();
                                    iziToast.success({
                                        title: 'Berhasil bubuhi QR',
                                        message: list_id.length + ' data',
                                        position: 'topRight'
                                    });
                                    $('#check-all').prop('checked', false); // Unchecks
                                } else {
                                    iziToast.error({
                                        title: 'Gagal bubuhi QR',
                                        message: list_id.length + ' data',
                                        position: 'topRight'
                                    });
                                }
                            },
                            error: function (xhr) {
                                iziToast.error(xhr.responseText, 'Error');
                            }
                        });
                    } else if (result.dismiss === "cancel") {
                        iziToast.info('data dibatalkan untuk dibubuhi QR', 'Info');
                    }
                });
            } else {
                iziToast.warning({
                    title: 'Perhatian',
                    message: 'Silahkan pilih data yang akan dibubuhi QR',
                    position: 'topRight'
                });
            }
        }
        <?php endif; ?>

        <?php if(in_array(Auth::user()->level, ['admin', 'superadmin','sespri'])): ?>
        $('#modal_form').on('shown.bs.modal', function () {
            $('#pthl_urut').focus()
        })

        if (jQuery().daterangepicker) {
            if ($("#pthl_tgl_lahir").length) {
                $('#pthl_tgl_lahir').daterangepicker({
                    locale: {format: 'DD/MM/YYYY'},
                    singleDatePicker: true,
                });
            }
        }
        <?php endif; ?>
        <?php if(in_array(Auth::user()->level, ['admin', 'superadmin'])): ?>
        function add() {
            $('#modal_form').modal();
            $('#modal_form').appendTo("body");
            $('#modal_form').modal('show'); // show bootstrap modal
            save_method = 'add';
            $('#form')[0].reset(); // reset form on modals
            $('.form-control').removeClass('is-invalid'); // clear error class
            $('.invalid-feedback').empty(); // clear error string
            $('#judul').text('FORM TAMBAH PTHL'); // Set Title to Bootstrap modal title
            $('#teksSimpan').text('Tambah');
            $('#btnsave').show();
            $('[name="pthl_urut"]').prop('disabled', false);
            $('[name="pthl_nama"]').prop('disabled', false);
            $('[name="pthl_nik"]').prop('disabled', false);
            $('[name="pthl_tempat_lahir"]').prop('disabled', false);
            $('[name="pthl_tgl_lahir"]').prop('disabled', false);
            $('[name="pthl_pendidikan"]').prop('disabled', false);
            $('[name="pthl_tugas"]').prop('disabled', false);
            $('[name="pthl_opd"]').prop('disabled', false);
            $('[name="dokumen_id"]').prop('disabled', false);
            $('[name="dokumen_id"]').val(1).trigger('change');
            $('#btnbatal').hide();
        }
        <?php endif; ?>
        <?php if(in_array(Auth::user()->level, ['admin', 'superadmin','sespri'])): ?>
        function initClick() {
            $(".clickable-edit").click(function () {
                save_method = 'update';
                pthl_id = $(this).attr('data-pthl_id');
                pthl_urut = $(this).attr('data-pthl_urut');
                pthl_nama = $(this).attr('data-pthl_nama');
                pthl_nik = $(this).attr('data-pthl_nik');
                pthl_tempat_lahir = $(this).attr('data-pthl_tempat_lahir');
                pthl_tgl_lahir = $(this).attr('data-pthl_tgl_lahir');
                pthl_pendidikan = $(this).attr('data-pthl_pendidikan');
                pthl_tugas = $(this).attr('data-pthl_tugas');
                pthl_opd = $(this).attr('data-pthl_opd');
                dokumen_id = $(this).attr('data-dokumen_id');
                $('#form')[0].reset(); // reset form on modals
                $('.form-control').removeClass('is-invalid'); // clear error class
                $('.invalid-feedback').empty(); // clear error string
                $('#modal_form').modal();
                $('#modal_form').appendTo("body");
                $('#modal_form').modal('show'); // sh
                $('[name="pthl_id"]').val(pthl_id);
                //alert(pthl_id);
                $('[name="pthl_urut"]').val(pthl_urut);
                $('[name="pthl_nama"]').val(pthl_nama);
                $('[name="dokumen_id"]').val(dokumen_id).trigger('change');
                $('[name="pthl_nik"]').val(pthl_nik);
                $('[name="pthl_tempat_lahir"]').val(pthl_tempat_lahir);
                $('[name="pthl_tgl_lahir"]').val(pthl_tgl_lahir);
                $('[name="pthl_pendidikan"]').val(pthl_pendidikan);
                $('[name="pthl_tugas"]').val(pthl_tugas);
                $('[name="pthl_opd"]').val(pthl_opd);
                $('#judul').text('FORM UBAH PTHL'); // Set Title to Bootstrap modal titlep modal title
                $('#teksSimpan').text('Simpan Perubahan');
                //$('#dokumen_file_text').text(dokumen_file);
                $('#btnsave').show();
                $('[name="pthl_id"]').prop('disabled', false);
                $('[name="pthl_urut"]').prop('disabled', false);
                $('[name="pthl_nama"]').prop('disabled', false);
                $('[name="pthl_nik"]').prop('disabled', false);
                $('[name="pthl_tempat_lahir"]').prop('disabled', false);
                $('[name="pthl_tgl_lahir"]').prop('disabled', false);
                $('[name="pthl_pendidikan"]').prop('disabled', false);
                $('[name="pthl_tugas"]').prop('disabled', false);
                $('[name="pthl_opd"]').prop('disabled', false);
                $('[name="dokumen_id"]').prop('disabled', false);
                $('#btnbatal').show();
                $('#btnbatal').text('Batal Ubah');
            });
        }


        function save() {
            var url;
            var _method;
            var id;
            var formData = new FormData($('#form')[0]);
            if (save_method == 'add') {
                id = '';
                url = "<?php echo e(url('dashboard/pthl/create/')); ?>";
                _method = "POST";
            } else {
                id = $('[name="pthl_id"]').val();
                url = '<?php echo e(url('dashboard/pthl/update/')); ?>' + '/' + id;
                _method = "PUT";
                formData.append('_method', 'PUT');
            }

            var token = $('meta[name="csrf-token"]').attr('content');
            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': token
                },
                url: url,
                type: 'POST',
                data: formData,
                dataType: "JSON",
                cache: false,
                contentType: false,
                processData: false,
                success: function (data) {
                    if (data.status) //if success close modal and reload ajax table
                    {
                        if (save_method == 'add') {
                            reloadTable();
                            iziToast.success({
                                title: 'Sukses',
                                message: 'Berhasil Input Data',
                                position: 'topRight'
                            });
                            $('#modal_form').modal('hide');
                        } else {
                            reloadTable();
                            iziToast.success({
                                title: 'Sukses',
                                message: 'Berhasil Ubah Data',
                                position: 'topRight'
                            });
                            $('#modal_form').modal('hide');
                        }
                    } else {
                        for (var i = 0; i < data.inputerror.length; i++) {
                            $('[name="' + data.inputerror[i] + '"]').addClass('is-invalid'); //select parent twice to
                            $('#error_' + data.inputerror[i] + '').text(data.error_string[i]);
                            $('[name="' + data.inputerror[i] + '"]').focus();
                        }
                    }
                },
                error: function (xhr) {
                    iziToast.error({
                        title: 'Error',
                        message: xhr.responseText,
                        position: 'topRight'
                    });
                }
            });
        }
        <?php endif; ?>

        $("#select_document").change(function () {
            getlink();
        });

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('mylayouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\e-dokumen\resources\views/dashboard_page/pthl/index.blade.php ENDPATH**/ ?>