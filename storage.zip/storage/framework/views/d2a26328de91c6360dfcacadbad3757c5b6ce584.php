
<?php $__env->startSection('title', 'Detail Surat Keluar (QR)'); ?>
<?php $__env->startPush('library-css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-body">
            <div class="row">
                <div class="col-sm-4 order-sm-0 order-lg-1 order-xl-1">
                    <div class="card">
                        <div class="card-body">
                            <div class="empty-state">
                                <?php if($berkas): ?>
                                    <a href="<?php echo e(url('berkas/'.$berkas)); ?>" target="_blank">
                                        <img class="img-fluid" style="height: 75px"
                                             src="<?php echo e(url('uploads/pdf_icon.png')); ?>"
                                             alt="image">
                                        <h2 class="mt-2 mb-2">Download Berkas</h2>
                                    </a>
                                <?php else: ?>
                                    <img class="img-fluid"
                                         src="<?php echo e(url('kodeqr/'.$qrcode)); ?>"
                                         alt="<?php echo e($no_surat); ?>">
                                    <h2 class="mt-2 mb-2">Surat Keluar (QR)</h2>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-8 order-sm-0 order-lg-0 order-xl-0">
                    <div class="card">
                        <div class="card-body">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">1. No Surat</label>

                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php echo e($no_surat); ?>

                                    </label>
                                </div>
                            </div>
                            <hr class="mb-2">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">2. Tgl Surat</label>

                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php echo e($tgl_surat); ?>

                                    </label>
                                </div>
                            </div>
                            <hr class="mb-2">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">3. Dari Perangkat Daerah</label>

                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php echo e($nama_opd); ?>

                                    </label>
                                </div>
                            </div>
                            <hr class="mb-2">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">4. Kepada</label>

                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php echo e($kepada); ?>

                                    </label>
                                </div>
                            </div>
                            <hr class="mb-2">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">5. Lampiran</label>

                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php echo e($lampiran); ?>

                                    </label>
                                </div>
                            </div>
                            <hr class="mb-2">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">6. Hal</label>

                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php echo e($perihal); ?>

                                    </label>
                                </div>
                            </div>
                            <hr class="mb-2">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">7. Ditandangani Oleh</label>

                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php echo e($jenis_ttd); ?>

                                    </label>
                                </div>
                            </div>
                            <hr class="mb-2">
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(assetku('assets/jshideyorix/general.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('mylayouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\e-dokumen\resources\views/dashboard_page/kodeqr/show.blade.php ENDPATH**/ ?>