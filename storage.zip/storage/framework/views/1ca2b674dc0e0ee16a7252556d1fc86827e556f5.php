<?php $__env->startSection('title', 'Form '.ucwords($mode).' Pimpinan / Instansi'); ?>
<?php $__env->startPush('vendor-css'); ?>
    <style>
        .select_sm {
            height: 33.22222px !important;
            padding-bottom: 2px !important;
            padding-top: 2px !important;
            padding-right: 2px !important;
            padding-left: 2px !important;
        }
    </style>
    <link rel="stylesheet" href="<?php echo e(assetku('assets/modules/datatables/Select-1.2.4/css/select.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(assetku('assets/modules/select2/dist/css/select2.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h1><?php echo e('Form '.ucwords($mode).' Pimpinan / Instansi'); ?></h1>
            <div class="section-header-breadcrumb">
                <div class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></div>
                <div class="breadcrumb-item"><a href="<?php echo e(route('perangkat-daerah')); ?>">Daftar PD</a></div>
                <div class="breadcrumb-item active"><?php echo e('Form '.ucwords($mode).' PD'); ?></div>
            </div>
        </div>
        <div class="section-body">
            <form id="form" name="form" role="form" action="<?php echo e($action); ?>"
                  enctype="multipart/form-data" method="post">
                <div class="row">

                    <div class="col-sm-8 order-sm-0 order-lg-1 order-xl-1">
                        <div class="card">

                            <?php echo e(csrf_field()); ?>

                            <?php if($mode=='ubah'): ?>
                                <?php echo e(method_field('PUT')); ?>

                            <?php endif; ?>
                            <div class="card-body">
                                <div class="col-sm-12">
                                    <div class="row mb-3">
                                        <label class="col-sm-3 col-lg-3 col-form-label">Nama</label>
                                        <div class="col-sm-9 col-lg-9">
                                            <div class="input-group">
                                 <span class="input-group-prepend">
                                 <label class="input-group-text">
                                 <i class="fa fa-building"></i></label>
                                 </span>
                                                <input class="form-control <?php $__errorArgs = ['nama_opd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                       placeholder="Contoh : Badan Perencanaan Daerah"
                                                       required="required" name="nama_opd" id="nama_opd"
                                                       type="text" value="<?php echo e($nama_opd); ?>">
                                            </div>
                                            <?php $__errorArgs = ['nama_opd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback" id="error_nama_opd">
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label class="col-sm-3 col-lg-3 col-form-label">Alias</label>
                                        <div class="col-sm-9 col-lg-9">
                                            <div class="input-group">
                                 <span class="input-group-prepend">
                                 <label class="input-group-text">
                                 <i class="fa fa-chalkboard-teacher"></i></label>
                                 </span>
                                                <input class="form-control <?php $__errorArgs = ['alias_opd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                       placeholder="Contoh : Bappeda"
                                                       required="required" name="alias_opd" id="alias_opd"
                                                       type="text"
                                                       value="<?php echo e($alias_opd); ?>">
                                            </div>
                                            <?php $__errorArgs = ['alias_opd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback" id="error_alias_opd">
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label class="col-sm-3 col-lg-3 col-form-label">Alamat</label>
                                        <div class="col-sm-9 col-lg-9">
                                            <div class="input-group">
                                 <span class="input-group-prepend">
                                 <label class="input-group-text">
                                 <i class="fa fa-address-book"></i></label>
                                 </span>
                                                <input
                                                    class="form-control <?php $__errorArgs = ['alamat_opd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    placeholder="Contoh : Komplek Perkantoran Pemda Lampung Timur"
                                                    name="alamat_opd" id="alamat_opd"
                                                    type="text" value="<?php echo e($alamat_opd); ?>">
                                            </div>
                                            <?php $__errorArgs = ['alamat_opd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback" id="error_alamat_opd">
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label class="col-sm-3 col-lg-3 col-form-label">Email</label>
                                        <div class="col-sm-9 col-lg-9">
                                            <div class="input-group">
                                 <span class="input-group-prepend">
                                 <label class="input-group-text">
                                 <i class="fa fa-envelope"></i></label>
                                 </span>
                                                <input class="form-control <?php $__errorArgs = ['email_opd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                       placeholder="Contoh : bappeda@lampungprov.go.id"
                                                       name="email_opd" id="email_opd"
                                                       type="email"
                                                       value="<?php echo e($email_opd); ?>">
                                            </div>
                                            <?php $__errorArgs = ['email_opd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback" id="error_email_opd">
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label class="col-sm-3 col-lg-3 col-form-label">No Telepon</label>
                                        <div class="col-sm-9 col-lg-9">
                                            <div class="input-group">
                                 <span class="input-group-prepend">
                                 <label class="input-group-text">
                                 <i class="fa fa-phone"></i></label>
                                 </span>
                                                <input
                                                    class="form-control <?php $__errorArgs = ['notelepon_opd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    placeholder="Contoh : (0721) 485458"
                                                    name="notelepon_opd" id="notelepon_opd"
                                                    type="text" onkeypress="return check_int(event)" maxlength="14"
                                                    value="<?php echo e($notelepon_opd); ?>">
                                            </div>
                                            <?php $__errorArgs = ['notelepon_opd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback" id="error_notelepon_opd">
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label class="col-sm-3 col-lg-3 col-form-label">Jenis</label>
                                        <div class="col-sm-9 col-lg-9">
                                            <div class="input-group">
                                                          <span class="input-group-prepend">
                                                          <label class="input-group-text">
                                                          <i class="fa fa-unlock"></i></label>
                                                          </span>
                                                <select name="jenis"
                                                        class="form-control <?php $__errorArgs = ['jenis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                    <option value="opd" <?php echo e($jenis=='opd' ? 'selected' : ''); ?>>OPD
                                                    </option>
                                                    <option
                                                        value="pimpinan daerah" <?php echo e($jenis=='pimpinan daerah' ? 'selected' : ''); ?>>
                                                        Pimpinan Daerah
                                                    </option>
                                                    <option
                                                        value="sekretariat daerah" <?php echo e($jenis=='sekretariat daerah' ? 'selected' : ''); ?>>
                                                        Sekretariat Daerah
                                                    </option>
                                                    <option value="tu" <?php echo e($jenis=='tu' ? 'selected' : ''); ?>>TU
                                                    </option>
                                                </select>
                                            </div>
                                            <?php $__errorArgs = ['jenis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback" id="error_jenis">
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label class="col-sm-3 col-lg-3 col-form-label">Status</label>
                                        <div class="col-sm-9 col-lg-9">
                                            <div class="input-group">
                                 <span class="input-group-prepend">
                                 <label class="input-group-text">
                                 <i class="fa fa-unlock"></i></label>
                                 </span>
                                                <select name="active"
                                                        class="form-control <?php $__errorArgs = ['active'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                    <option value="1" <?php echo e($active==1 ? 'selected' : ''); ?>>Aktif
                                                    </option>
                                                    <option value="0" <?php echo e($active==0 ? 'selected' : ''); ?>>Tidak Aktif
                                                    </option>
                                                </select>
                                            </div>
                                            <?php $__errorArgs = ['active'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback" id="error_active">
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer text-right bg-whitesmoke">
                                <?php if($mode=='tambah'): ?>
                                    <button type="reset" class="btn btn-secondary mr-2">Reset Form</button>
                                <?php endif; ?>
                                <button type="submit" class="btn btn-primary mr-2"><i class="mr-50 fa fa-save"></i>
                                    <?php if($mode=='ubah'): ?> Simpan Perubahan <?php else: ?> Submit <?php endif; ?>
                                </button>
                            </div>

                        </div>
                    </div>
                    <div class="col-sm-4 order-sm-0 order-lg-0 order-xl-0">
                        <div class="card">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>ID Simpedu (Unit Kerja)</label>
                                            <select class="select_cari form-control" id="T_KUnker"
                                                    name="T_KUnker">
                                                <option value="">Pilih</option>
                                                <?php $__currentLoopData = $listUnkerSimpedu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option
                                                        value="<?php echo e($x->T_KUnker.'|'.$x->Unit_Kerja); ?>" <?php echo e($x->T_KUnker==$T_KUnker ? 'selected' : ''); ?>><?php echo e($x->Unit_Kerja.' - '.$x->T_KUnker); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php $__errorArgs = ['T_KUnker'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="empty-state">
                                            <img class="img-fluid"
                                                 src="<?php echo e(assetku('assets/img/drawkit/drawkit-full-stack-man-colour.svg')); ?>"
                                                 alt="image">

                                            <?php if(count($errors) > 0): ?>
                                                <div class="alert alert-danger alert-dismissible fade show"
                                                     role="alert">
                                                    <div class="alert-body">
                                                        <ul>
                                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <li><?php echo e($error); ?></li>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </ul>
                                                    </div>
                                                    <button type="button" class="close" data-dismiss="alert"
                                                            aria-label="Close">
                                                        <span aria-hidden="true">×</span>
                                                    </button>
                                                </div>
                                            <?php endif; ?>


                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                </div>
            </form>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(assetku('assets/modules/select2/dist/js/select2.full.min.js')); ?>"></script>
    <script src="<?php echo e(assetku('assets/jshideyorix/general.js')); ?>"></script>
    <!--begin::Page Scripts(used by this page)-->
    <script type="text/javascript">
        <?php if(session('pesan_status')): ?>
        tampilPesan('<?php echo e(session('pesan_status.tipe')); ?>', '<?php echo e(session('pesan_status.desc')); ?>', '<?php echo e(session('pesan_status.judul')); ?>');
        <?php endif; ?>


        function getnamaunitkerja() {
            var uk = $('#T_KUnker').val();
            var explode = uk.split("|");
            $('#nama_opd').val(explode[1]);
        }

        $('#T_KUnker').change(function () {
            getnamaunitkerja();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('mylayouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\e-dokumen\resources\views/dashboard_page/perangkat-daerah/form.blade.php ENDPATH**/ ?>
