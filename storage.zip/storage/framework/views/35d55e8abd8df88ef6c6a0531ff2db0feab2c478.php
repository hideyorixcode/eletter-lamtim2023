
<?php $__env->startSection('title', 'Form Tanda Tangan Surat Keluar '); ?>
<?php $__env->startPush('vendor-css'); ?>
    <link rel="stylesheet" href="<?php echo e(assetku('magnific-popup/magnific-popup.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(assetku('assets/modules/datatables/Select-1.2.4/css/select.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(assetku('assets/modules/select2/dist/css/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(assetku('assets//modules/bootstrap-daterangepicker/daterangepicker.css')); ?>">
    <style>
        .select_sm {
            height: 33.22222px !important;
            padding-bottom: 2px !important;
            padding-top: 2px !important;
            padding-right: 2px !important;
            padding-left: 2px !important;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h1><?php echo e('Tanda Tangan Surat Keluar Menggunakan Elektronik'); ?></h1>
            <div class="section-header-breadcrumb">
                <div class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></div>
                <div class="breadcrumb-item"><a href="<?php echo e(route('surat-keluar')); ?>">Daftar Surat Keluar TTE </a></div>
                <div class="breadcrumb-item active"><?php echo e('Tanda Tangan'); ?></div>
            </div>
        </div>
        <div class="section-body">
            <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <div class="alert-body">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
            <?php endif; ?>
            <div class="row">
                <div class="col-sm-4 order-sm-0 order-lg-1 order-xl-1">
                    <div class="card">
                        <div class="card-body">
                            <div class="empty-state">
                                <?php if($berkas): ?>
                                    <a href="<?php echo e(url('berkas/temp/'.$berkas)); ?>" target="_blank">
                                        <img class="img-fluid" style="height: 75px"
                                             src="<?php echo e(url('uploads/pdf_icon.png')); ?>"
                                             alt="image">
                                        <h2 class="mt-2 mb-2">Cek Berkas</h2>
                                    </a>
                                <?php else: ?>
                                    <img class="img-fluid"
                                         src="<?php echo e(url('kodeqr/'.$qrcode)); ?>"
                                         alt="<?php echo e($no_surat); ?>">
                                    <h2 class="mt-2 mb-2">Surat Keluar </h2>
                                <?php endif; ?>
                            </div>
                            <form id="form" name="form" role="form" action="<?php echo e($action); ?>"
                                  enctype="multipart/form-data" method="post" autocomplete="off">
                                <?php echo e(csrf_field()); ?>


                                <div class="form-group">
                                    <label>NIK</label>
                                    <input type="hidden" class="form-control" name="id" id="id"
                                           value="<?php echo e($id); ?>" readonly>
                                    <input type="password" class="form-control" name="nik" id="nik"
                                           value="<?php echo e($jenis_ttd->nik); ?>" readonly>
                                    <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>

                                <div class="form-group">
                                    <label>Passphrase</label>
                                    <input type="password"
                                           class="form-control <?php $__errorArgs = ['passphrase'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           name="passphrase" id="passphrase" value="">
                                    <?php $__errorArgs = ['passphrase'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>

                                <button type="submit" class="btn btn-primary">Tanda Tangan Surat</button>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-sm-8 order-sm-0 order-lg-0 order-xl-0">
                    <div class="card">
                        <div class="card-body">

                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">1. No Surat</label>

                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php echo e($no_surat); ?>

                                    </label>
                                </div>
                            </div>
                            <hr class="mb-2">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">2. Tgl Surat</label>

                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php echo e($tgl_surat); ?>

                                    </label>
                                </div>
                            </div>
                            <hr class="mb-2">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">3. Dari Perangkat Daerah /
                                        Pimpinan</label>

                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php echo e($nama_opd); ?>

                                    </label>
                                </div>
                            </div>
                            <hr class="mb-2">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">4. Kepada</label>

                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php
                                            $kepadaOke = $kepada;
                                            if ($tujuan == 'dalam' || $tujuan == 'keduanya') {
                                            $kepadaOke = $kepada_opd.';';
                                            $kepadaOke .= $kepada;
                                            $explode_kepada = explode(';', rtrim($kepadaOke, ';'));
                                            $kepada = '';
                                            foreach ($explode_kepada as $value) {
                                            $kepada .= '- ' . $value . ' <br/>';
                                            }
                                            }
                                        ?>
                                        <?php echo $kepada; ?>

                                    </label>
                                </div>
                            </div>
                            <hr class="mb-2">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">5. Lampiran</label>

                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php echo e($lampiran); ?>

                                    </label>
                                </div>
                            </div>
                            <hr class="mb-2">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">6. Hal</label>

                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php echo e($perihal); ?>

                                    </label>
                                </div>
                            </div>
                            <hr class="mb-2">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">7. Ditandangani Oleh</label>

                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php echo e($jenis_ttd->jenis_ttd); ?>

                                    </label>
                                </div>
                            </div>
                            <hr class="mb-2">
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(assetku('assets/modules/select2/dist/js/select2.full.min.js')); ?>"></script>
    <script src="<?php echo e(assetku('assets/modules/jquery-ui/jquery-ui.min.js')); ?>"></script>
    <script src="<?php echo e(assetku('magnific-popup/jquery.magnific-popup.min.js')); ?>"></script>
    <script src="<?php echo e(assetku('assets/modules/bootstrap-daterangepicker/daterangepicker.js')); ?>"></script>
    <script src="<?php echo e(assetku('assets/jshideyorix/general.js')); ?>"></script>
    <!--begin::Page Scripts(used by this page)-->
    <script type="text/javascript">
        <?php if(session('pesan_status')): ?>
        tampilPesan('<?php echo e(session('pesan_status.tipe')); ?>', '<?php echo e(session('pesan_status.desc')); ?>', '<?php echo e(session('pesan_status.judul')); ?>');
        <?php endif; ?>

        if (jQuery().daterangepicker) {
            if ($("#tgl_surat").length) {
                $('#tgl_surat').daterangepicker({
                    locale: {format: 'DD/MM/YYYY'},
                    singleDatePicker: true,
                });
            }
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('mylayouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\e-dokumen\resources\views/dashboard_page/suratkeluartte/formpenandatangan.blade.php ENDPATH**/ ?>