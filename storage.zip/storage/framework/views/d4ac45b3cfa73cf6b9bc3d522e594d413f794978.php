<?php if(count($listPengguna)>0): ?>
    <?php $no = ($listPengguna->currentpage()-1)* $listPengguna->perpage() + 1;?>
    <div class="card card-success">
        <div class="card-body">
            <ul class="list-unstyled user-progress list-unstyled-border list-unstyled-noborder">
                <?php $__currentLoopData = $listPengguna; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataPengguna): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $activePengguna = $dataPengguna->active;
                        $warnaActive = $activePengguna==1 ? '<span class="badge badge-pill badge-light-success"> AKTIF </span>' : '<span class="badge badge-pill badge-light-danger"> NON AKTIF </span>';
                        $avatar = $dataPengguna->avatar ? url('uploads/'.$dataPengguna->avatar) :url('uploads/blank.png');
                        $thumb = $dataPengguna->avatar ? url('uploads/thumbnail/'.$dataPengguna->avatar) :url('uploads/blank.png');
                    ?>

                    <li class="media">
                        <a class="image-popup-no-margins" href="<?php echo e($avatar); ?>">
                            <img alt="image" class="mr-3 rounded-circle" width="50" src="<?php echo e($thumb); ?>">
                        </a>
                        <div class="media-body">
                            <div class="row">
                                <div class="col-md-5">
                                    <div class="media-title"><?php echo e($dataPengguna->name); ?></div>
                                    <div class="text-muted"><?php echo e($dataPengguna->email); ?></div>
                                    <div class="text-muted"><?php echo e($dataPengguna->username); ?></div>
                                </div>
                                <div class="col-md-7">
                                    <div class="form-group row m-0">
                                        <label class="col-4 col-form-label">Level:</label>
                                        <div class="col-8">
                                            <span
                                                class="form-control-plaintext font-weight-bolder"><?php echo e($dataPengguna->level); ?></span>
                                        </div>
                                    </div>
                                    <?php if($dataPengguna->id_opd_fk!=''): ?>
                                        <div class="form-group row m-0">
                                            <label class="col-4 col-form-label">Bertugas di :</label>
                                            <div class="col-8">
                                                <span
                                                    class="form-control-plaintext font-weight-bolder"><?php echo e($dataPengguna->nama_opd); ?></span>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    <div class="form-group row m-0">
                                        <label class="col-4 col-form-label">Status Akun:</label>
                                        <div class="col-8">
                                                <span class="form-control-plaintext font-weight-bolder"><div
                                                        class="<?php echo e(getActive($dataPengguna->active)); ?> text-small font-600-bold"><i
                                                            class="fas fa-circle"></i> <?php echo e(getActiveTeks($dataPengguna->active)); ?></div></span>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="">
                            <div class="btn-group" role="group" aria-label="First group">
                                <a href="<?php echo e(url('dashboard/pengguna/show/'.Hashids::encode($dataPengguna->id))); ?>"
                                   class="btn btn-sm btn-outline-warning btn-icon"
                                   title="Show"><i class="fa fa-eye"></i></a>
                                <a href="<?php echo e(url('dashboard/pengguna/edit/'.Hashids::encode($dataPengguna->id))); ?>"
                                   class="btn btn-sm btn-outline-success btn-icon"
                                   title="Edit"><i class="fa fa-edit"></i></a>
                                <a href="javascript:void(0)"
                                   onclick="deleteData('<?php echo e(Hashids::encode($dataPengguna->id)); ?>')"
                                   class="btn btn-sm btn-outline-danger btn-icon" title="Hapus"><i
                                        class="fa fa-trash"></i></a>
                                <a href="javascript:void(0)"
                                   class="btn btn-sm btn-outline-primary btn-icon"
                                   title="Pilih"><input
                                        type="checkbox"
                                        <?php if(in_array(Hashids::encode($dataPengguna->id), $arrayList)): ?> checked
                                        <?php endif; ?> onchange="checkBulk()"
                                        value="<?php echo e(Hashids::encode($dataPengguna->id)); ?>"
                                        class="data-check"></a>
                            </div>
                        </div>
                    </li>

                    <?php $no++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
    <div class="card card-dark mb-2">
        <div class="card-body mb-0">
            <div class="row">
                <div class="col-md-8">
                    <div class="dropdown d-inline">
                        <button class="btn btn-dark dropdown-toggle" type="button" id="dropdownMenuButton2"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Pilih Opsi
                        </button>
                        <div class="dropdown-menu">
                            <a class="dropdown-item has-icon" href="javascript:bulkDelete()"><i
                                    class="fa fa-trash text-danger"></i> Hapus yang dipilih</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 text-right">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="custom-control custom-checkbox">
                                <input type="checkbox" class="custom-control-input"
                                       id="check-all">
                                <label class="custom-control-label" for="check-all">Seluruh
                                    Data</label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <select class="form-control selectrowCount" name="page_count"
                                    id="page_count" style="border-right-width: 0px;
                     border-bottom-width: 0px;
                     padding-top: 0px;
                     padding-right: 0px;
                     padding-left: 0px;
                     padding-bottom: 0px;
                     height: 22.22222px;
                     width: 72.22222px;">
                                <option disabled>Jumlah Tampil</option>
                                <?php $__currentLoopData = $paginateList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        value=<?php echo e($value); ?> <?php echo e($value==$page_count ? 'selected' : ''); ?>><?php echo e($value == -1 ? 'ALL' : $value); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo e($listPengguna->links()); ?>

<?php else: ?>
    <div class="alert alert-primary alert-dismissible fade show" role="alert">
        <div class="alert-body">
            TIDAK DITEMUKAN DATA
        </div>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
        </button>
    </div>
<?php endif; ?>
<?php /**PATH D:\xampp\htdocs\e-dokumen\resources\views/dashboard_page/pengguna/data.blade.php ENDPATH**/ ?>