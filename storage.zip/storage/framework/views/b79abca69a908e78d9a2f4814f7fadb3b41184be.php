<?php if(count($listNomor)>0): ?>
    <div class="row">
        <?php $no = ($listNomor->currentpage()-1)* $listNomor->perpage() + 1;
            $iterasi = 1;
        ?>
        <?php $__currentLoopData = $listNomor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nomor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-12">
                <div class="card card-danger">
                    <div class="card-header">
                        <h4><?php echo e($nomor->nomor_dokumen); ?></h4>
                        <div class="card-header-action">
                            <a class="btn btn-icon btn-info"
                               href="<?php echo e(url('dashboard/pns/detail-pelaksana/'.Hashids::encode($nomor->id))); ?>"><i
                                    class="fas fa-user-plus"></i> Data Pegawai</a>
                            <div class="dropdown">
                                <a href="#" data-toggle="dropdown"
                                   class="btn btn-warning dropdown-toggle">Actions</a>
                                <div class="dropdown-menu">
                                    <a href="#" class="dropdown-item has-icon clickable-edit"
                                       data-id="<?php echo e(Hashids::encode($nomor->id)); ?>"
                                       data-dokumen_id="<?php echo e($nomor->dokumen_id); ?>"
                                       data-tanggal_dokumen="<?php echo e(TanggalIndo2($nomor->tanggal_dokumen)); ?>"
                                       data-nomor_dokumen="<?php echo e($nomor->nomor_dokumen); ?>"
                                       data-tentang_dokumen="<?php echo e($nomor->tentang_dokumen); ?>"
                                       data-opd_id="<?php echo e($nomor->opd_id); ?>"
                                    ><i class="far fa-edit"></i> Ubah</a>
                                    <div class="dropdown-divider"></div>
                                    <a href="javascript:void(0)" class="dropdown-item has-icon text-danger"
                                       onclick="deleteData('<?php echo e(Hashids::encode($nomor->id)); ?>')"><i
                                            class="far fa-trash-alt"></i> Hapus</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card-body">
                        <ul class="list-group">
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                Instansi
                                <span class="font-weight-bolder"><?php echo e($nomor->opd->nama_opd); ?></span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                Tanggal Dokumen
                                <span class=""><?php echo e(TanggalIndo2($nomor->tanggal_dokumen)); ?></span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                Jumlah SK Pegawai
                                <span class="badge badge-primary badge-pill"><?php echo e($nomor->pns_count); ?></span>
                            </li>
                        </ul>
                    </div>

                </div>
            </div>
            <?php $iterasi++; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php echo e($listNomor->links()); ?>

<?php else: ?>
    <div class="alert alert-primary alert-dismissible fade show" role="alert">
        <div class="alert-body">
            TIDAK DITEMUKAN DATA
        </div>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
        </button>
    </div>
<?php endif; ?>
<?php /**PATH D:\xampp\htdocs\e-dokumen\resources\views/dashboard_page/pelaksana/data.blade.php ENDPATH**/ ?>