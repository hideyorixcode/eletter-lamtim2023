<?php $__env->startSection('title', 'Logs Pengguna'); ?>
<?php $__env->startPush('library-css'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h1>Log Aktivitas Pengguna</h1>
            <div class="section-header-breadcrumb">
                <div class="breadcrumb-item active"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></div>
                <div class="breadcrumb-item">Log Aktivitas Pengguna</div>
            </div>
        </div>

        <div class="section-body">
            <h2 class="section-title">Hi, <?php echo e(Auth::user()->name); ?></h2>
            <p class="section-lead">
                Log Aktivitas anda
            </p>

            <div class="row mt-sm-4">
                <div class="col-12 col-md-12 col-lg-5">
                    <div id="renderviewSide">
                    </div>
                </div>
                <div class="col-12 col-md-12 col-lg-7">
                    <?php echo $__env->make('components.loader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div id="renderviewData">
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">
        $(document).ready(function() {
            getViewData(1);
            getViewSide();
        });

        $(document).on('click', '.pagination a', function (event) {
            event.preventDefault();
            var page = $(this).attr('href').split('page=')[1];
            getViewData(page);
        });

        function getViewData(page) {
            var pagenya = page ? page : 1;
            $(".loaderData").show();
            var urlData = "<?php echo e(url('dashboard/data-logs')); ?>";
            $.ajax({
                url: urlData,
                type: "GET",
                data:
                    {
                        page: pagenya,
                    },
                success: function (data) {
                    $('#renderviewData').html(data);
                    $(".loaderData").hide();
                }
            });
        }

        <?php
            $segment = Request::segment(1).'/'.Request::segment(2);
        ?>

        function getViewSide() {
            $(".loaderData").show();
            var urlData;

            urlData = "<?php echo e(url('dashboard/side-profil')); ?>";

            $.ajax({
                url: urlData,
                type: "GET",
                data:
                    {
                        segment: '<?php echo e($segment); ?>',
                    },
                success: function (data) {
                    $('#renderviewSide').html(data);
                    $(".loaderData").hide();
                }
            });
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('mylayouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\e-dokumen\resources\views/dashboard_page/pengguna/logs.blade.php ENDPATH**/ ?>