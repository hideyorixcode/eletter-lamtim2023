<div id="container_grafik"></div>
<script>
    $(document).ready(function () {
        $('#container_grafik').highcharts({
            chart: {
                type: 'column'
            },
            title: {
                text: 'Statistik Penandatangan'
            },
            subtitle: {
                text: 'Total Seluruh <?php echo e($tahun); ?>'
            },
            xAxis: {
                categories: [
                    //'Jan',
                    <?php $__currentLoopData = $jenisttd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ttd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        '<?php echo e($ttd->jenis_ttd); ?>',
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                ],
                crosshair: true,
                allowDecimals: false
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Jumlah'
                }
            },
            tooltip: {
                headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                    '<td style="padding:0"><b>{point.y} </b></td></tr>',
                footerFormat: '</table>',
                shared: true,
                useHTML: true
            },
            plotOptions: {
                column: {
                    pointPadding: 0.2,
                    borderWidth: 0
                }
            },
            series: [
                {

                    name: 'Tanda Tangan Basah',
                    data: [
                        <?php $__currentLoopData = $jenisttd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ttd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e(getJumlahJenisTTD($ttd->id_jenis_ttd, 'basah', $tahun, $bulan).','); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    ]

                }, {
                    name: 'Tanda Tangan Elektronik',
                    data: [
                        <?php $__currentLoopData = $jenisttd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ttd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e(getJumlahJenisTTD($ttd->id_jenis_ttd, 'elektronik', $tahun, $bulan).','); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    ]


                },
            ],
        });
    });

</script>
<?php /**PATH D:\laragon\www\eletter\resources\views/dashboard_page/jenis-penandatangan/render.blade.php ENDPATH**/ ?>