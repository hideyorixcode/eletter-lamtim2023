<?php $__env->startSection('title', 'Cetak Data Surat Masuk'); ?>
<?php $__env->startPush('library-css'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
            <td align="center"><strong>CETAK QR-CODE
                    Surat <?php echo e($sifat_surat == 'biasa' ? 'Masuk' : ucwords($sifat_surat)); ?></strong><br/>

            </td>
        </tr>
    </table>
    <br/>
    <table class="table table-bordered table-striped">
        <tbody>
        <tr>
            <td class="font-weight-bold">Kode</td>
            <td><?php echo e($kode); ?></td>
        </tr>
        <tr>
            <td class="font-weight-bold">Nomor Agenda</td>
            <td><?php echo e($indek); ?></td>
        </tr>
        <tr>
            <td class="font-weight-bold">No Surat</td>
            <td><?php echo e($no_surat); ?></td>
        </tr>
        <tr>
            <td class="font-weight-bold">Tanggal Surat</td>
            <td><?php echo e($tgl_surat); ?></td>
        </tr>
        <tr>
            <td class="font-weight-bold">Lampiran</td>
            <td><?php echo e($lampiran); ?></td>
        </tr>
        <tr>
            <td class="font-weight-bold">Dari</td>
            <td><?php echo e($dari); ?></td>
        </tr>
        <tr>
            <td class="font-weight-bold">Kepada</td>
            <td><?php echo e(cek_opd($kepada)->nama_opd); ?></td>
        </tr>
        <tr>
            <td class="font-weight-bold">Hal</td>
            <td><?php echo e($perihal); ?></td>
        </tr>
        <?php if($catatan): ?>
        <tr>
            <td class="font-weight-bold">Catatan Perjalanan Surat</td>
            <td><?php echo e($catatan); ?></td>
        </tr>
        <?php endif; ?>
        <tr>
            <td class="font-weight-bold">QR</td>
            <td>><img src="<?php echo e(url('kodeqr/'.$qrcode)); ?>" alt=""/></td>
        </tr>
        </tbody>
    </table>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('mylayouts.print', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\e-dokumen\resources\views/dashboard_page/suratmasuk/cetak.blade.php ENDPATH**/ ?>