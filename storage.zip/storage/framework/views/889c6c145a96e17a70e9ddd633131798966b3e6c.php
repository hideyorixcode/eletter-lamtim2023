<!DOCTYPE html>
<html lang="en">
<!-- BEGIN: Head-->
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0,user-scalable=0,minimal-ui">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="description" content="<?php echo e(getSetting('deskripsi')); ?>">
    <meta name="keywords" content="<?php echo e(getSetting('keyword')); ?>">
    <meta name="author" content="<?php echo e(getSetting('author')); ?>">
    <title><?php echo e(getSetting('nama_app')); ?> - <?php echo $__env->yieldContent('title'); ?></title>
    <!--favicon-->
    <link rel="icon" type="image/x-icon" href="<?php echo e(url('uploads/'.getSetting('favicon'))); ?>">
    <!--plugins-->
    <link rel="stylesheet" href="<?php echo e(assetku('assets/modules/bootstrap/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(assetku('assets/modules/fontawesome/css/all.min.css')); ?>">
    <?php echo $__env->yieldPushContent('vendor-css'); ?>
    <link rel="stylesheet" href="<?php echo e(assetku('assets/modules/izitoast/css/iziToast.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(assetku('assets/css/styledokumen.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(assetku('assets/css/components.css')); ?>">
    <?php echo $__env->yieldPushContent('library-css'); ?>
</head>
<!-- END: Head-->

<!-- BEGIN: Body-->
<body>
<!--wrapper-->
<div id="app">
    <section class="section">
        <div class="d-flex flex-wrap align-items-stretch">
            <div class="col-lg-4 col-md-6 col-12 order-lg-1 min-vh-100 order-2 bg-white">
                <div class="p-4 m-3">
                    <img src="<?php echo e(url('uploads/'.getSetting('logo'))); ?>" alt="logo" width="80"
                         class="shadow-light rounded-circle mb-5 mt-2">
                    <h4 class="text-dark font-weight-normal"><span
                            class="font-weight-bold"><?php echo e(getSetting('nama_app')); ?></span>
                    </h4>
                    <?php echo $__env->yieldContent('content'); ?>

                    <div class="text-center mt-5 text-small">
                        Hak Cipta &copy; <?php echo e(getSetting('author')); ?>

                    </div>
                    <div class="text-center mt-1 text-small">
                        Terintegrasi dengan Sertifikat Elektronik yang di terbitkan oleh : <img src="<?php echo e(url('uploads/logo-bsre.png')); ?>" width="100px">
                    </div>

                </div>
            </div>
            <div
                class="col-lg-8 col-12 order-lg-2 order-1 min-vh-100 background-walk-y position-relative overlay-gradient-bottom"
                data-background="<?php echo e(url('uploads/'.getSetting('banner_login'))); ?>">
                <div class="absolute-bottom-left index-2">
                    <div class="text-light p-5 pb-2">
                        <div class="mb-5 pb-3">
                            <h1 class="mb-2 display-4 font-weight-bold"><?php echo e(getSetting('area')); ?></h1>
                            <h5 class="font-weight-normal text-muted-transparent"><?php echo e(getSetting('alamat')); ?></h5>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<!--end wrapper-->
<!-- General JS Scripts -->
<script src="<?php echo e(assetku('assets/modules/jquery.min.js')); ?>"></script>
<script src="<?php echo e(assetku('assets/modules/popper.js')); ?>"></script>
<script src="<?php echo e(assetku('assets/modules/tooltip.js')); ?>"></script>
<script src="<?php echo e(assetku('assets/modules/bootstrap/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(assetku('assets/modules/nicescroll/jquery.nicescroll.min.js')); ?>"></script>
<script src="<?php echo e(assetku('assets/modules/moment.min.js')); ?>"></script>
<script src="<?php echo e(assetku('assets/js/stisla.js')); ?>"></script>
<script src="<?php echo e(assetku('assets/modules/izitoast/js/iziToast.min.js')); ?>"></script>
<!-- JS Libraies -->

<!-- Template JS File -->
<script src="<?php echo e(assetku('assets/js/scripts.js')); ?>"></script>
<script src="<?php echo e(assetku('assets/js/custom.js')); ?>"></script>

<!-- Page Specific JS File -->
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
<!-- END: Body-->
</html>
<?php /**PATH D:\xampp\htdocs\e-dokumen\resources\views/mylayouts/authlayout.blade.php ENDPATH**/ ?>