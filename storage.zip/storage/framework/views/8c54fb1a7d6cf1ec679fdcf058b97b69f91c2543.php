<?php $__env->startSection('title', 'Detail Surat Keluar '); ?>
<?php $__env->startPush('library-css'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <section class="section mt-3">
        <div class="section-body">
            <div class="row">
                <div class="col-sm-4 order-sm-0 order-lg-1 order-xl-1">
                    <div class="card">
                        <div class="card-body">
                            <div class="empty-state">
                                <?php if($berkas): ?>
                                    <?php if($is_download==1): ?>
                                            <?php
                                            if ($status_sk == 'draft') {
                                                if ($kategori_ttd == 'elektronik') {
                                                    $link = url('berkas/temp/' . $berkas);
                                                } else {
                                                    $link = url('berkas/' . $berkas);
                                                }
                                            } else {
                                                $link = url('berkas/' . $berkas);
                                            }
                                            ?>
                                        <a href="<?php echo e($link); ?>" target="_blank">
                                            <img class="img-fluid" style="height: 75px"
                                                 src="<?php echo e(url('uploads/pdf_icon.png')); ?>"
                                                 alt="image">
                                            <h2 class="mt-2 mb-2">Download Berkas</h2>
                                        </a>
                                    <?php else: ?>
                                        <img class="img-fluid"
                                             src="<?php echo e(url('kodeqr/'.$qrcode)); ?>"
                                             alt="<?php echo e($no_surat); ?>">
                                        <h2 class="mt-2 mb-2">Surat Keluar </h2>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <img class="img-fluid"
                                         src="<?php echo e(url('kodeqr/'.$qrcode)); ?>"
                                         alt="<?php echo e($no_surat); ?>">
                                    <h2 class="mt-2 mb-2">Surat Keluar </h2>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-8 order-sm-0 order-lg-0 order-xl-0">
                    <div class="card">
                        <div class="card-body">
                            <div class="col-sm-12">

                                <?php
                                    if($status_sk=='final')
                                    {
                                    $alert = 'primary';
                                    $teksalert = 'Status Dokumen : Final';
                                    }
                                    else if($status_sk=='draft')
                                    {
                                    $alert = 'danger';
                                    $teksalert = 'Status Dokumen : Draft';
                                    }
                                    else
                                    {
                                    $alert ='warning';
                                    $teksalert = 'Status Dokumen : Revisi';
                                    }
                                ?>
                                <div class="alert alert-<?php echo e($alert); ?>">
                                    <?php echo e($teksalert); ?>

                                </div>

                            </div>
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">1. No Surat</label>
                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php echo $no_surat!='' ? $no_surat : '
                                        <div class="p-1 color bg-danger text-white"> Belum Diberikan Nomor </div>
                                        '; ?>

                                    </label>
                                </div>
                            </div>
                            <hr class="mb-2">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">2. Tgl Surat</label>
                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php echo e($tgl_surat); ?>

                                    </label>
                                </div>
                            </div>
                            <hr class="mb-2">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">3. Dari Perangkat Daerah /
                                        Pimpinan</label>
                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php echo e($nama_opd); ?>

                                    </label>
                                </div>
                            </div>
                            <hr class="mb-2">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">4. Kepada</label>
                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php
                                            $kepadaOke = $kepada;
                                            if ($tujuan == 'dalam' || $tujuan == 'keduanya') {
                                            $kepadaOke = $kepada_opd.';';
                                            $kepadaOke .= $kepada;
                                            $explode_kepada = explode(';', rtrim($kepadaOke, ';'));
                                            $kepada = '';
                                            foreach ($explode_kepada as $value) {
                                            $kepada .= '- ' . $value . ' <br/>';
                                            }
                                            }
                                        ?>
                                        <?php echo $kepada; ?>

                                    </label>
                                </div>
                            </div>
                            <hr class="mb-2">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">5. Lampiran</label>
                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php echo e($lampiran); ?>

                                    </label>
                                </div>
                            </div>
                            <hr class="mb-2">
                            <div class="col-sm-12">
                                <div class="row mb-3">
                                    <label class="col-sm-5 col-lg-5 col-form-label">6. Hal</label>
                                    <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                        <?php echo e($perihal); ?>

                                    </label>
                                </div>
                            </div>
                            <?php if($jenis_ttd): ?>
                                <hr class="mb-2">
                                <div class="col-sm-12">
                                    <div class="row mb-3">
                                        <label class="col-sm-5 col-lg-5 col-form-label">7. Ditandangani Oleh</label>
                                        <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                            <?php echo e($jenis_ttd->jenis_ttd.' - '.cek_opd($jenis_ttd->id_opd_fk)->nama_opd); ?>

                                        </label>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <?php if($kategori_ttd): ?>
                                <hr class="mb-2">
                                <div class="col-sm-12">
                                    <div class="row mb-3">
                                        <label class="col-sm-5 col-lg-5 col-form-label">8. Metode Tanda Tangan</label>
                                        <label class="col-sm-7 col-lg-7 col-form-label font-weight-bolder">
                                            <?php echo e($kategori_ttd=='basah' ? 'TANDA TANGAN BASAH' : 'TANDA TANGAN ELEKTRONIK'); ?>

                                        </label>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(assetku('assets/jshideyorix/general.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('mylayouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\eletter\resources\views/dashboard_page/suratkeluar/show.blade.php ENDPATH**/ ?>