<div class="activity">
    <div class="activity-icon bg-dark text-white shadow-danger">
        <i class="fas fa-bell"></i>
    </div>
    <div class="activity-detail" style="width: 100%">
        <div class="mb-2">
            <p>Surat Dalam Perjalanan ke : <strong><?php echo e(cek_opd($data->penerima)->nama_opd); ?></strong></p>
        </div>
    </div>
</div>

<?php /**PATH D:\xampp\htdocs\e-dokumen\resources\views/dashboard_page/suratmasuk/tanggalkosonguser.blade.php ENDPATH**/ ?>