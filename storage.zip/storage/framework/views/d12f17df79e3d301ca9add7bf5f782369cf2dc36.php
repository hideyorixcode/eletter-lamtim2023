<div class="alert alert-light alert-dismissible show fade">
    <div class="alert-body">
        <button class="close" data-dismiss="alert">
            <span>×</span>
        </button>
        ketika anda gagal upload PDF, silahkan untuk merubah versi PDF anda menjadi versi 1.4 melalui link berikut <a
            href="https://docupub.com/pdfconvert/" target="_blank">LINK MERUBAH VERSI</a> dan pilih versi compability nya menjadi <strong>Acrobat 5.0 (PDF 1.4) </strong> dan upload kembali pada form
        ini.
    </div>
</div>
<?php /**PATH D:\laragon\www\eletter\resources\views/components/infoubahversipdf.blade.php ENDPATH**/ ?>