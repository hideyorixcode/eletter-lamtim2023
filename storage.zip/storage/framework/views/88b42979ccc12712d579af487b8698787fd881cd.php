<?php ?>
<div class="loaderData card text-center mb-5" style="display: none">
    <button class="btn btn-outline-primary waves-effect" type="button" disabled="">
        <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
        <span class="ml-25 align-middle">Loading...</span>
    </button>
</div>


<?php /**PATH D:\xampp\htdocs\e-dokumen\resources\views/components/loader.blade.php ENDPATH**/ ?>